"""GARDAVU : planification locale des gardes."""

__version__ = "1.1.7"
__author__ = "Dr Florian Ronez"
