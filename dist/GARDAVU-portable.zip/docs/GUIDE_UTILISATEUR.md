# Guide utilisateur

## Projet et données

Créer ou ouvrir un fichier `.gardavu` avec les boutons du haut. Le chemin ouvert
est toujours visible. Un fichier est verrouillé pendant l'ouverture ; une seconde
instance ne peut pas l'écrire. Fermer l'application avant de déplacer l'original.
Les données sont enregistrées à chaque action, sans bouton de sauvegarde générale.

**Sauvegarder / Copier** réalise une copie SQLite cohérente vers un **nouveau**
fichier. **Restaurer** ouvre une sauvegarde et la restaure vers un nouveau fichier,
sans écraser l'original. Les sauvegardes automatiques sont dans le dossier
`<nom du projet>_sauvegardes`, à côté du projet, avec date et raison.
Elles précèdent imports et validations/remplacements. Les migrations futures
doivent aussi utiliser cette sauvegarde avant modification du schéma.

Les données ne sont pas chiffrées. Protéger l'accès au dossier, conserver une copie
sur un autre support, et partager volontairement le projet. Le logiciel n'utilise
ni AppData ni le registre pour les données. Le fichier `.lock` adjacent est un
support de verrou système, pas une seconde base : il peut rester après fermeture.

## Médecins et absences

Chaque médecin possède un identifiant stable. Le nom peut évoluer sans changer
ses anciennes gardes. La désactivation prend effet à la date choisie, sans
suppression de l'historique. Pour un retour, conserver la même fiche, retirer la
désactivation et compléter les périodes de participation ou de suspension.

Les périodes se saisissent une par ligne, sous la forme
`2026-11-01..2027-04-30`, bornes incluses. Une fin vide signifie sans limite.
Pour un seul jour, saisir la même date aux deux extrémités.

- Participation : dates d'appartenance au groupe.
- Suspension / absence longue : interdit l'affectation et neutralise la cible
  pendant la période. Aucun motif médical n'est nécessaire, aucune dette de retour.
- Indisponibilité ponctuelle : interdit la date sans diminuer automatiquement la cible.
- Coefficient : choix explicite de charge relative, 1 par défaut, 0,5 pour moitié.
- Maximums total et mensuel : limites impératives sur la période calculée.

## Besoins et règles

Sélectionner `soir` puis **Nouvelle version d'un modèle** pour renseigner les horaires
réellement décidés. Les horaires historiques restent enregistrés indépendamment.
Chaque modification du modèle a une prise d'effet. Une nouvelle version désactivée
permet d'arrêter un modèle à partir d'une date.

Les fériés remplacent la journée ordinaire : deux créneaux, jamais un doublon de
samedi ou dimanche. Nuit signifie 19 h à minuit, sans créneau minuit–8 h.
Minuit s'écrit `24:00` ou `00:00` en fin de garde : il s'agit du lendemain.

**Exception à une date** remplace l'ensemble des modèles de cette journée.
Pour deux créneaux exceptionnels, saisir successivement deux identifiants distincts.
Le récapitulatif affiche toutes les exceptions ; la commande permet de supprimer
l'exception ou de désactiver toute la date.

**Fêtes / dates particulières** ajoute ou retire des identifiants stables à une date.
Une correction de date nécessite un retrait à l'ancienne date puis un ajout à la
nouvelle. Pour une veille soumise à rotation, utiliser par exemple `VEILLE_NOEL`.
Les 24 et 31 décembre ne sont pas fériés automatiquement. Deux identifiants le
même jour partagent la couverture sans ajouter des créneaux.

Dans **Paramètres du calcul**, confirmer l'espacement minimal. Sept jours est une
proposition organisationnelle, aucune obligation réglementaire n'est affirmée.
L'espacement s'applique avant et après la période à toutes les gardes effectives
connues. Le mode STRICT interdit la même fête dans la fenêtre ; PRIORITAIRE la
défavorise et impose une confirmation des répétitions avant validation.

## Importer

Deux assistants distincts : médecins et historique. Choisir le fichier `.xlsx` ou
CSV UTF-8, la feuille, la ligne des en-têtes et la correspondance des colonnes.
L'aperçu expose les erreurs, avertissements et rapprochements nécessaires.
Les formules sont refusées ; coller les valeurs avant l'import. Les fichiers
`.xls`, macros et calendriers graphiques non tabulaires ne sont pas interprétés.

Pour les médecins : ID facultatif pour une création. Pour une fiche déjà connue,
fournir l'ID explicite ; un nom identique ne provoque aucune fusion automatique.
Pour les homonymes, fournir des ID distincts.

Historique en lignes : date, médecin ou ID, catégorie ; horaires, fête, statut et
ID de créneau facultatifs. Catégories : SEMAINE, SAMEDI, DIMANCHE_JOUR,
DIMANCHE_NUIT, FERIE_JOUR, FERIE_NUIT (les libellés français sont aussi acceptés).
Historique en tableau : date en ligne, une colonne par catégorie, une cellule =
un médecin ou ID. Pour plusieurs postes d'un créneau, utiliser le format en lignes
avec un ID de créneau commun et l'effectif requis.

Les noms ambigus exigent un rapprochement explicite. Si plusieurs personnes ont
exactement le même texte source, compléter le fichier avec leurs identifiants
avant import pour distinguer chaque affectation. Les horaires manquants restent
inconnus. Les dates servent à l'espacement, mais les heures et certains
chevauchements historiques ne peuvent pas être reconstitués.

Un conflit avec une garde existante bloque par défaut. Choisir explicitement
**Ignorer** ou **Remplacer / corriger**, puis confirmer. Les versions antérieures
restent tracées sans compter dans les gardes effectives. Le même fichier avec
les mêmes paramètres et les mêmes lignes s'importe sans doubler les gardes.

La déclaration de **couverture connue complète** est manuelle. Elle exige le
contrôle de toutes les gardes ET des participations/coefficient correspondants.
Une plage entre première et dernière date ne démontre pas cette couverture.
Sans attestation suffisante, l'historique sert à l'espacement et aux fêtes,
sans imposer une compensation de charge ancienne à un nouvel arrivant.

## Calcul et examen

La fin saisie fait foi. Le bouton de calcul des mois indique la fin incluse avant
génération. Exemple : 01/11/2026–30/04/2027 = six mois. Une date en milieu de mois
est conservée ; si son anniversaire n'existe pas dans le mois cible, il est ramené
au dernier jour, puis exclu (la veille est la fin incluse).

Vérifier les besoins : quatre semaines sans férié nécessitent 32 affectations
pour les modèles initiaux. « Environ une garde par mois » est un objectif,
pas un plafond de 30 gardes. Des mois avec deux gardes sont donc normaux.

Le calcul s'exécute dans un fil séparé. Annuler demande l'arrêt et conserve la
meilleure solution conforme déjà obtenue par CP-SAT. Sans solution trouvée,
UNKNOWN signifie absence de conclusion. Les diagnostics précisent si un conflit
est prouvé ou si seule une piste d'analyse est proposée. Ne pas valider un planning
incomplet. FEASIBLE indique une solution conforme avec optimalité non démontrée.

Dans le planning, filtrer par médecin ou catégorie. Les vues chronologique et
mensuelle suivent les mêmes filtres. Sélectionner une ligne pour modifier le
médecin, deux lignes (Ctrl-clic) pour échanger deux affectations. Libérer les
verrous avant de modifier leurs affectations. Chaque changement est enregistré
en brouillon, contrôlé et répercuté dans les statistiques.

**Régénérer** conserve les verrous de la version affichée.
**Modifier le moins possible** place la conservation des affectations futures
avant les objectifs souples. Les gardes passées connues sont gelées et ne peuvent
pas être échangées ou réécrites par la validation d'un remplacement.

## Valider, archiver et exporter

Les contrôles indépendants bloquent les affectations incomplètes, indisponibles,
hors participation, chevauchantes, trop rapprochées, sur quota ou contraires aux
verrous. Une répétition de fête en mode PRIORITAIRE exige une confirmation.
Un remplacement de période exige aussi une confirmation distincte.

Une version validée est immuable : sa modification crée un nouveau brouillon.
Archiver conserve les gardes dans l'historique effectif. Un remplacement conserve
les anciens enregistrements, mais une seule affectation reste effective.

Les exports portent leur état, période et version. Un brouillon reste identifié
**BROUILLON — NON VALIDÉ** ; une ligne sans affectation reste marquée incomplète.
L'Excel contient Planning, Équité, Jours fériés, Paramètres et avertissements.
Les identifiants masqués du planning restent disponibles pour réimportation
(choisir la troisième ligne comme en-têtes). Le CSV porte aussi état et IDs.
Les textes pouvant ressembler à des formules sont protégés. Aucun motif d'absence
n'est demandé ni transmis.
