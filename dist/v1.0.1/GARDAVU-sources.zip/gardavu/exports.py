"""Exports lisibles et réimportables ; aucune formule issue de texte utilisateur."""
from dataclasses import asdict
from datetime import date
import csv
import json
from pathlib import Path
from math import ceil

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .domain import CATEGORIES, dumps
from .targets import statistics

HEADERS = ["Date", "Médecin", "Catégorie", "Début", "Fin", "Fête", "Statut",
           "ID médecin", "ID créneau", "Effectif", "Période", "Version"]


def safe(value):
    if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@", "\t", "\r", "\n")):
        return "'" + value
    return value


def plan_label(plan):
    return {"BROUILLON": "BROUILLON — NON VALIDÉ", "VALIDE": "VALIDÉ",
            "ARCHIVE": "ARCHIVÉ", "REMPLACE": "REMPLACÉ — NON EFFECTIF"}[plan.state]


def planning_rows(plan, doctors):
    if plan.state != "BROUILLON" and plan.metadata.get("doctors_snapshot"):
        from .domain import Doctor
        doctors = [Doctor.from_dict(d) for d in plan.metadata["doctors_snapshot"]]
    names = {d.id: d.name for d in doctors}
    for s in plan.slots:
        roster = plan.assignments.get(s.id) or [""]
        for ident in roster:
            yield [s.date, names.get(ident, "NON AFFECTÉ"), s.category, s.start, s.end,
                   ",".join(s.holidays), plan.state if ident else "INCOMPLET — NON VALIDÉ",
                   ident, s.id, s.required, f"{plan.start} au {plan.end}", plan.id]


def style_sheet(ws, header=1):
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = f"B{header + 1}"
    ws.auto_filter.ref = f"A{header}:{get_column_letter(ws.max_column)}{ws.max_row}"
    for c in ws[header]:
        c.fill = PatternFill("solid", fgColor="244454")
        c.font = Font(name="Arial", color="FFFFFF", bold=True, size=10)
        c.alignment = Alignment(horizontal="center", vertical="center")
    for row in ws.iter_rows(min_row=header + 1):
        for c in row:
            c.font = Font(name="Arial", size=10)
            c.alignment = Alignment(vertical="center")
            if isinstance(c.value, date):
                c.number_format = "dd/mm/yyyy"
            elif isinstance(c.value, float):
                c.number_format = "0.00"
            if c.data_type == "f":
                raise ValueError("Une formule inattendue a été détectée avant export.")
    for col in ws.columns:
        length = max((len(str(c.value or "")) for c in col), default=10)
        ws.column_dimensions[col[0].column_letter].width = min(64, max(13, length + 2))
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0
    ws.print_title_rows = f"{header}:{header}"
    ws.oddFooter.center.text = "GARDAVU — Page &P / &N"


def append(ws, row):
    ws.append([safe(v) for v in row])


def parameter_rows(key, value):
    if isinstance(value, dict):
        for child, item in value.items():
            yield from parameter_rows(f"{key} / {child}", item)
    elif isinstance(value, list):
        for number, item in enumerate(value, 1):
            yield from parameter_rows(f"{key} / {number}", item)
    else:
        yield key, value


def export_excel(path, plan, doctors, history=(), warnings=()):
    wb = Workbook()
    ws = wb.active
    ws.title = "Planning"
    ws.append([f"GARDAVU — {plan_label(plan)} — {plan.start} au {plan.end}"])
    ws.append([])
    ws.append(HEADERS)
    for row in planning_rows(plan, doctors):
        append(ws, row)
    style_sheet(ws, 3)
    ws.sheet_properties.tabColor = "244454"
    # Identifiants disponibles sans gêner la lecture courante.
    for letter in ("H", "I", "J", "L"):
        ws.column_dimensions[letter].hidden = True
    eq = wb.create_sheet("Équité")
    months = sorted({s.day[:7] for s in plan.slots})
    eq.append(["Médecin", "Cible", "Attribué", "Écart", "Mois à plusieurs gardes", "Heures", "Espacement min (j)",
               *CATEGORIES.values(), "Total fériés", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", *months, "ID médecin"])
    for row in statistics(plan, doctors, history):
        append(eq, [row["medecin"], row["cible"], row["total"], row["ecart"], row["mois_multiples"], row["heures"], row["espacement_min"],
                    *[row["categories"].get(c, 0) for c in CATEGORIES], row["feries"],
                    *[row["jours_semaine"].get(n, 0) for n in range(5)],
                    *[row["mois"].get(m, 0) for m in months], row["id"]])
    style_sheet(eq)
    fh = wb.create_sheet("Jours fériés")
    fh.append(["Date", "Fête", "Catégorie", "Médecin", "Occurrences antérieures connues", "ID médecin"])
    for row in statistics(plan, doctors, history):
        for s in plan.slots:
            if s.holidays and row["id"] in plan.assignments.get(s.id, []):
                previous = sorted({r.slot.day for r in history if r.doctor_id == row["id"] and r.slot.day < s.day and set(r.slot.holidays).intersection(s.holidays)})
                append(fh, [s.date, ", ".join(s.holidays), s.category, row["medecin"], ", ".join(previous) or "Aucune occurrence connue", row["id"]])
    style_sheet(fh)
    params = wb.create_sheet("Paramètres et avertissements")
    params.append(["Paramètre", "Valeur"])
    for key, value in {"État": plan_label(plan), "Début inclus": plan.start, "Fin incluse": plan.end,
                       "Version": plan.id, "Statut du solveur": plan.solver_status, **plan.metadata}.items():
        if key == "doctors_snapshot":
            continue  # Les absences individuelles ne font pas partie de l'export collectif.
        if key == "rules" and "validated_rules" in plan.metadata:
            continue
        for row in parameter_rows(key, value):
            append(params, row)
    for warning in warnings:
        append(params, ["Avertissement", warning])
    style_sheet(params)
    params.column_dimensions['A'].width = 55
    params.column_dimensions['B'].width = 95
    for row in params.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(vertical="top", wrap_text=True)
        params.row_dimensions[row[0].row].height = max(20, 15 * max(ceil(len(str(row[0].value or '')) / 52), ceil(len(str(row[1].value or '')) / 90)))
    wb.save(path)


def export_csv(path, plan, doctors):
    with Path(path).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(HEADERS)
        for row in planning_rows(plan, doctors):
            row[0] = row[0].isoformat()
            writer.writerow([safe(v) for v in row])


def create_templates(folder):
    folder = Path(folder)
    folder.mkdir(exist_ok=True, parents=True)
    definitions = {
        "modele_medecins.xlsx": (["ID", "Nom", "Prénom", "Coefficient", "Début participation", "Fin participation"],
                                  ["DEMO-001", "EXEMPLE FICTIF", "Camille", 1, date(2026, 1, 1), None]),
        "modele_historique.xlsx": (HEADERS[:10], [date(2026, 12, 25), "EXEMPLE FICTIF Camille", "FERIE_JOUR", "08:00", "19:00", "NOEL", "VALIDE", "DEMO-001", "2026-12-25:ferie-jour", 1]),
        "modele_historique_tableau.xlsx": (["Date", "Soir de semaine", "Samedi", "Dimanche jour", "Dimanche nuit", "Férié jour", "Férié nuit"],
                                          [date(2026, 12, 25), None, None, None, None, "DEMO-001", "DEMO-002"]),
    }
    result = []
    for name, (headers, example) in definitions.items():
        wb = Workbook()
        ws = wb.active
        ws.title = "Données"
        ws.append(headers)
        ws.append(example)
        style_sheet(ws)
        instructions = wb.create_sheet("Instructions")
        instructions.append(["Instruction"])
        instructions.append(["Supprimer la ligne d'exemple fictif avant de saisir vos données."])
        instructions.append(["Les horaires historiques absents restent inconnus. Statuts effectifs : VALIDE ou ARCHIVE."])
        instructions.append(["En tableau : une colonne par catégorie, une cellule contenant un seul médecin ou son identifiant."])
        instructions.append(["En lignes : une ligne par affectation. Conserver les identifiants pour une réimportation fiable."])
        instructions.append(["Aucune formule ni macro. Dates JJ/MM/AAAA ou dates Excel."])
        style_sheet(instructions)
        wb.save(folder / name)
        result.append(folder / name)
    return result
