import argparse
from dataclasses import asdict
from datetime import date
import json
from pathlib import Path
import sys


def self_test(folder):
    """Recette transportable du binaire ; écrit un rapport exploitable sans console."""
    from .calendar import generate_slots
    from .demo import configured_rules, demo_doctors
    from .domain import Plan
    from .exports import export_excel, export_csv
    from .solver import solve
    from .storage import Project
    from .validation import validate
    folder = Path(folder).resolve()
    folder.mkdir(parents=True, exist_ok=True)
    report = {"success": False, "frozen": bool(getattr(sys, "frozen", False)), "python": sys.version}
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        root.update()
        root.destroy()
        report["tkinter"] = "OK"
        doctors, rules = demo_doctors(), configured_rules(12)
        slots = generate_slots(date(2027, 2, 1), date(2027, 2, 28), rules)
        result = solve(Plan("2027-02-01", "2027-02-28", slots), doctors, rules, [])
        validation = validate(result, doctors, rules, [])
        if validation.errors or not result.assignments:
            raise ValueError("; ".join(validation.errors or result.metadata.get("errors", [])))
        with Project(folder / "Recette éç.gardavu", create=True) as project:
            for d in doctors:
                project.save_doctor(d)
            project.save_rules(rules)
            project.save_draft(result)
            result = project.validate_plan(result)
            project.backup(folder / "Copie.gardavu")
        with Project(folder / "Copie.gardavu") as copy:
            assert len(copy.history()) == 32
        export_excel(folder / "Planning.xlsx", result, doctors)
        export_csv(folder / "Planning.csv", result, doctors)
        from .ui import App
        app = App()
        app.withdraw()
        app.set_project(Project(folder / "Recette éç.gardavu"))
        app.plan = result
        app.refresh_plan()
        app.update()
        report["ui_rows"] = len(app.planning_tree.get_children())
        app.close()
        report.update(success=True, assignments=sum(map(len, result.assignments.values())), status=result.solver_status,
                      elapsed_seconds=result.metadata["elapsed_seconds"])
    except Exception as exc:
        import traceback
        report.update(error=str(exc), traceback=traceback.format_exc())
    (folder / "rapport.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0 if report["success"] else 1


def main():
    parser = argparse.ArgumentParser(description="GARDAVU — application locale de répartition des gardes")
    parser.add_argument("--self-test", metavar="DOSSIER_NEUF", help="Exécuter une recette fictive du binaire")
    parser.add_argument("--demo", metavar="PROJET", help="Créer un projet fictif .gardavu distinct")
    parser.add_argument("--templates", metavar="DOSSIER", help="Générer les modèles Excel")
    parser.add_argument("--open", metavar="PROJET", help="Ouvrir un projet .gardavu")
    args = parser.parse_args()
    if args.self_test:
        return self_test(args.self_test)
    if args.demo:
        from .demo import create_demo
        create_demo(args.demo)
        return 0
    if args.templates:
        from .exports import create_templates
        create_templates(args.templates)
        return 0
    from .ui import App
    app = App()
    if args.open:
        from .storage import Project
        try:
            app.set_project(Project(args.open))
        except Exception as exc:
            from tkinter import messagebox
            messagebox.showerror("Projet inaccessible", str(exc), parent=app)
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
