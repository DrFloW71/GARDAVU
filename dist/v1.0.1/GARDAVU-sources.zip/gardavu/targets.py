"""Cibles rationnelles avant toute indisponibilité ponctuelle."""
from collections import Counter, defaultdict
from fractions import Fraction
from math import ceil
import hashlib
from .domain import Doctor, Plan, Record, Slot


def calculate_targets(slots: list[Slot], doctors: list[Doctor]):
    target = defaultdict(Fraction)
    for s in slots:
        participants = [d for d in doctors if d.participates(s.date)]
        total = sum((Fraction(str(d.coefficient)) for d in participants), Fraction())
        if not total:
            raise ValueError(f"{s.day} : aucun participant pour répartir la charge théorique.")
        for d in participants:
            share = Fraction(s.required) * Fraction(str(d.coefficient)) / total
            for key in ("TOTAL", f"MOIS:{s.day[:7]}", f"CAT:{s.category}"):
                target[d.id, key] += share
            if s.category.startswith("FERIE"):
                target[d.id, "FERIES"] += share
    return target


def scaled_targets(values: dict[str, Fraction], scale=1000, salt=""):
    """Méthode des plus forts restes ; somme conservée, erreur < 1/scale.

    Avec salt, le dernier millième est départagé par une empreinte de période et
    d'identifiant : les mêmes identifiants ne sont pas favorisés à chaque tour.
    Les cibles affichées restent les fractions non arrondies.
    """
    result = {key: (value * scale).numerator // (value * scale).denominator for key, value in values.items()}
    missing = round(sum(values.values()) * scale) - sum(result.values())
    def tie(key):
        return hashlib.sha256(f"{salt}:{key}".encode()).hexdigest() if salt else key
    order = sorted(values, key=lambda key: (-(values[key] * scale - result[key]), tie(key)))
    for key in order[:missing]:
        result[key] += 1
    return result


def statistics(plan: Plan, doctors, history=()):
    if plan.state != "BROUILLON" and plan.metadata.get("doctors_snapshot"):
        doctors = [Doctor.from_dict(d) for d in plan.metadata["doctors_snapshot"]]
    targets = calculate_targets(plan.slots, doctors)
    rows = []
    for d in doctors:
        assigned = [s for s in plan.slots if d.id in plan.assignments.get(s.id, [])]
        months = Counter(s.day[:7] for s in assigned)
        cats = Counter(s.category for s in assigned)
        weekdays = Counter(s.date.weekday() for s in assigned if s.category == "SEMAINE")
        dates = sorted(s.date for s in assigned)
        past = [r.slot.date for r in history if r.doctor_id == d.id]
        gaps = [abs((a - b).days) for i, a in enumerate(dates) for b in dates[:i] + past]
        rows.append({"id": d.id, "medecin": d.name, "cible": float(targets[d.id, "TOTAL"]),
                     "total": len(assigned), "ecart": len(assigned) - float(targets[d.id, "TOTAL"]),
                     "mois": dict(months), "mois_multiples": sum(n > 1 for n in months.values()),
                     "categories": dict(cats), "jours_semaine": dict(weekdays),
                     "heures": sum(s.hours or 0 for s in assigned),
                     "espacement_min": min(gaps) if gaps else None,
                     "feries": sum(n for c, n in cats.items() if c.startswith("FERIE")),
                     "fetes": [{"date": s.day, "fetes": list(s.holidays),
                                "precedentes": sorted({r.slot.day for r in history
                                    if r.doctor_id == d.id and r.slot.day < s.day
                                    and set(s.holidays).intersection(r.slot.holidays)})}
                               for s in assigned if s.holidays]})
    return rows
