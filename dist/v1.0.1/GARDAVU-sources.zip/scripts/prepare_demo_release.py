"""Ajouter un brouillon calculé et son export au projet de démonstration."""
from pathlib import Path
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from gardavu.domain import Plan
from gardavu.exports import export_excel
from gardavu.storage import Project

root = Path(__file__).resolve().parents[1]
plan = Plan.from_dict(json.loads((root / 'artifacts/benchmark-historique-release/plan.json').read_text(encoding='utf-8')))
with Project(root / 'demo/DEMONSTRATION.gardavu') as project:
    project.save_draft(plan, 'brouillon_fictif_livraison')
    export_excel(root / 'demo/Planning_fictif.xlsx', plan, project.doctors(), project.history(), plan.metadata.get('warnings', []))
