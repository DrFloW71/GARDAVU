# Jeu fictif

`DEMONSTRATION.gardavu` : 30 médecins nommés FICTIF 01 à FICTIF 30, identifiants
DEMO-001 à DEMO-030, dix années de gardes fictives du 01/01/2016 au 31/12/2025.
Graine 42, fichier généré avec `python -m gardavu --demo demo/DEMONSTRATION.gardavu`.
Les participations de démonstration sont identiques. Les soirs 19 h–minuit sont
des paramètres fictifs, pas les horaires confirmés du groupe réel.

Le fichier est séparé de l'archive du logiciel. Ne pas importer ce jeu dans un
projet réel. La couverture historique n'est pas attestée automatiquement.

Un brouillon fictif calculé pour novembre 2026 à avril 2027 est également
enregistré dans le projet. Double-cliquer sa ligne dans Projet et période.
`Planning_fictif.xlsx` permet d'examiner l'export sans toucher aux données réelles.
