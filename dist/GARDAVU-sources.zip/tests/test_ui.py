from datetime import date
import tkinter as tk

from gardavu.domain import Plan, Slot
from gardavu.exports import export_excel
from gardavu.storage import Project
from gardavu.ui import App, ImportWizard, parse_spans


def test_ui_project_plan_filter_and_import_preview(tmp_path, rules, doctors):
    app = App()
    app.withdraw()
    try:
        p = Project(tmp_path / 'Interface été.gardavu', create=True)
        p.save_rules(rules)
        for d in doctors[:2]:
            p.save_doctor(d)
        app.set_project(p)
        a = Slot('a', '2030-02-01', 'SEMAINE', '19:00', '24:00')
        b = Slot('b', '2030-02-09', 'SAMEDI', '14:00', '24:00')
        app.plan = Plan(a.day, b.day, [a, b], {'a': ['DEMO-001'], 'b': ['DEMO-002']})
        app.project.save_draft(app.plan)
        app.refresh()
        app.update()
        assert len(app.planning_tree.get_children()) == 2
        assert len(app.equity_tree.get_children()) == 2
        app.filter_doctor.set(next(k for k, v in app.filter_options.items() if v == 'DEMO-001'))
        app.refresh_plan()
        assert len(app.planning_tree.get_children()) == 1
        assert app.month_grid.winfo_children()
        app.plan.assignments['b'] = ['DEMO-001']
        app.plan.assignments['a'] = []
        app.after_edit('test_controle_modification')
        assert app.plan.solver_status == 'MODEL_INVALID'
        assert 'NON VALIDÉ' in app.plan_status.cget('text')
        app.plan.state = 'VALIDE'
        app.plan.assignments = {'a': ['DEMO-001'], 'b': ['DEMO-002']}
        path = tmp_path / 'export.xlsx'
        export_excel(path, app.plan, doctors[:2])
        from gardavu.imports import read_sheets
        wizard = ImportWizard(app, 'history')
        wizard.withdraw()
        wizard.path = str(path)
        wizard.sheets = read_sheets(path)
        wizard.sheet.set('Planning')
        wizard.header.set('3')
        wizard.build_mapping.__wrapped__(wizard)
        wizard.prepare.__wrapped__(wizard)
        assert len(wizard.preview.records) == 2 and not wizard.preview.errors
        assert not wizard.preview.unresolved
        wizard.destroy()
    finally:
        app.close()


def test_span_entry_inclusive_and_open_end():
    spans = parse_spans('2030-01-01..2030-01-02\n2031-01-01..')
    assert spans[0].contains(date(2030, 1, 2))
    assert not spans[0].contains(date(2030, 1, 3))
    assert spans[1].contains(date(2040, 1, 1))
