"""Interface locale Tk/ttk. Le calcul s'exécute hors du fil graphique."""
from __future__ import annotations

import calendar
from copy import deepcopy
from dataclasses import asdict
from datetime import date, timedelta
from functools import wraps
import json
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from .calendar import add_months, generate_slots, period_end
from .domain import CATEGORIES, Doctor, Plan, Rules, Span, Template, dumps, parse_date, uid
from .exports import create_templates, export_csv, export_excel, plan_label
from .imports import (category, commit_import, conflicts, data_rows, file_fingerprint,
                      normalize, prepare_doctors, prepare_history, read_sheets)
from .solver import Cancellation, solve
from .storage import Project
from .targets import calculate_targets, statistics
from .validation import validate


def guarded(fn):
    @wraps(fn)
    def wrapped(self, *args, **kwargs):
        try:
            return fn(self, *args, **kwargs)
        except Exception as exc:
            messagebox.showerror("GARDAVU — Action interrompue", str(exc), parent=self)
    return wrapped


def tree(parent, columns, height=15):
    frame = ttk.Frame(parent)
    frame.pack(fill="both", expand=True, pady=6)
    widget = ttk.Treeview(frame, columns=list(range(len(columns))), show="headings", height=height)
    for n, label in enumerate(columns):
        widget.heading(n, text=label)
        widget.column(n, width=145 if n else 180, minwidth=75)
    sy = ttk.Scrollbar(frame, orient="vertical", command=widget.yview)
    sx = ttk.Scrollbar(frame, orient="horizontal", command=widget.xview)
    widget.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
    widget.grid(row=0, column=0, sticky="nsew")
    sy.grid(row=0, column=1, sticky="ns")
    sx.grid(row=1, column=0, sticky="ew")
    frame.rowconfigure(0, weight=1)
    frame.columnconfigure(0, weight=1)
    return widget


def text_area(parent, height=12):
    frame = ttk.Frame(parent)
    frame.pack(fill="both", expand=True, pady=5)
    area = tk.Text(frame, wrap="word", height=height, font=("Segoe UI", 10), padx=10, pady=8)
    area.pack(side="left", fill="both", expand=True)
    scroll = ttk.Scrollbar(frame, command=area.yview)
    scroll.pack(side="right", fill="y")
    area.configure(yscrollcommand=scroll.set)
    return area


def show_text(area, content):
    area.configure(state="normal")
    area.delete("1.0", "end")
    area.insert("1.0", content)
    area.configure(state="disabled")


class Form(tk.Toplevel):
    """Champs (clé, libellé, valeur, choix ou 'multiline')."""
    def __init__(self, parent, title, fields, submit, note=""):
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.result = None
        self.submit = submit
        self.values = {}
        body = ttk.Frame(self, padding=16)
        body.pack(fill="both", expand=True)
        if note:
            ttk.Label(body, text=note, wraplength=690).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        for row, (key, label, value, options) in enumerate(fields, 1):
            ttk.Label(body, text=label).grid(row=row, column=0, sticky="nw", padx=(0, 12), pady=4)
            if options == "multiline":
                widget = tk.Text(body, width=62, height=4, font=("Segoe UI", 10))
                widget.insert("1.0", value)
            elif options:
                widget = ttk.Combobox(body, values=options, state="readonly", width=59)
                widget.set(str(value))
            else:
                widget = ttk.Entry(body, width=62)
                widget.insert(0, str(value) if value is not None else "")
            widget.grid(row=row, column=1, sticky="ew", pady=4)
            self.values[key] = widget
        ttk.Button(body, text="Enregistrer", command=self.accept).grid(row=len(fields) + 1, column=1, sticky="e", pady=14)
        body.columnconfigure(1, weight=1)
        self.grab_set()

    @guarded
    def accept(self):
        values = {key: widget.get("1.0", "end").strip() if isinstance(widget, tk.Text) else widget.get().strip()
                  for key, widget in self.values.items()}
        self.submit(values)
        self.result = values
        self.destroy()


def spans_text(spans):
    return "\n".join(f"{s.start}..{s.end or ''}" for s in spans)


def parse_spans(text):
    spans = []
    for line in text.splitlines():
        if line.strip():
            bits = line.strip().split("..")
            start = parse_date(bits[0]).isoformat()
            end = parse_date(bits[1]).isoformat() if len(bits) > 1 and bits[1].strip() else None
            spans.append(Span(start, end))
    return spans


class ImportWizard(tk.Toplevel):
    def __init__(self, app, mode):
        super().__init__(app)
        self.app, self.mode = app, mode
        self.title("Importer des médecins" if mode == "doctors" else "Importer un historique")
        self.geometry("1080x790")
        self.transient(app)
        self.preview = None
        self.sheets = {}
        self.resolutions = {}
        self.mapping = {}
        self.matrix_widgets = {}
        bar = ttk.Frame(self, padding=12)
        bar.pack(fill="x")
        ttk.Button(bar, text="1. Choisir un fichier .xlsx / .csv", command=self.choose).pack(side="left")
        self.sheet = ttk.Combobox(bar, state="readonly", width=26)
        self.sheet.pack(side="left", padx=8)
        self.sheet.bind("<<ComboboxSelected>>", self.build_mapping)
        ttk.Label(bar, text="Ligne des en-têtes :").pack(side="left")
        self.header = ttk.Spinbox(bar, from_=1, to=200, width=5)
        self.header.set("1")
        self.header.pack(side="left", padx=5)
        ttk.Button(bar, text="Actualiser colonnes", command=self.build_mapping).pack(side="left")
        self.kind = tk.StringVar(value="Lignes")
        if mode == "history":
            ttk.Combobox(bar, textvariable=self.kind, values=["Lignes", "Tableau"], state="readonly", width=10).pack(side="left", padx=8)
        self.mapping_frame = ttk.LabelFrame(self, text="2. Correspondance des colonnes (vide = absent)", padding=10)
        self.mapping_frame.pack(fill="x", padx=12)
        actions = ttk.Frame(self, padding=12)
        actions.pack(fill="x")
        ttk.Button(actions, text="3. Aperçu et rapprochement", command=self.prepare).pack(side="left")
        ttk.Button(actions, text="Rapprocher un nom ambigu", command=self.resolve).pack(side="left", padx=8)
        self.policy = ttk.Combobox(actions, values=["Bloquer les conflits", "Ignorer les conflits", "Remplacer / corriger les conflits"], state="readonly", width=35)
        self.policy.set("Bloquer les conflits")
        self.policy.pack(side="left")
        self.confirm = ttk.Button(actions, text="4. Confirmer l'import", command=self.commit, state="disabled")
        self.confirm.pack(side="right")
        self.info = text_area(self)
        show_text(self.info, "Choisissez la feuille et les colonnes, examinez l'aperçu, puis confirmez.\nLes formules sont refusées. Les calendriers graphiques arbitraires doivent être convertis au modèle fourni.")

    @guarded
    def choose(self):
        path = filedialog.askopenfilename(parent=self, filetypes=[("Données", "*.xlsx *.csv")])
        if path:
            self.path = path
            self.sheets = read_sheets(path)
            self.sheet.configure(values=list(self.sheets))
            self.sheet.set(next(iter(self.sheets)))
            self.resolutions.clear()
            self.build_mapping()

    @guarded
    def build_mapping(self, event=None):
        self.confirm.configure(state="disabled")
        self.preview = None
        if not self.sheets:
            return
        for child in self.mapping_frame.winfo_children():
            child.destroy()
        headers, _ = data_rows(self.sheets[self.sheet.get()], int(self.header.get()) - 1)
        fields = {"id": "ID", "nom": "Nom", "prenom": "Prénom", "coefficient": "Coefficient",
                  "debut": "Début participation", "fin": "Fin participation"} if self.mode == "doctors" else {
                      "date": "Date", "medecin": "Médecin", "id_medecin": "ID médecin", "categorie": "Catégorie",
                      "debut": "Début", "fin": "Fin", "fete": "Fête", "statut": "Statut", "id_creneau": "ID créneau", "effectif": "Effectif"}
        self.mapping = {}
        for n, (key, label) in enumerate(fields.items()):
            row, group = divmod(n, 4)
            ttk.Label(self.mapping_frame, text=label).grid(row=row * 2, column=group, sticky="w", padx=8)
            combo = ttk.Combobox(self.mapping_frame, values=["", *headers], state="readonly", width=26)
            combo.set(next((h for h in headers if normalize(h) == normalize(label)), ""))
            combo.grid(row=row * 2 + 1, column=group, padx=8, pady=(0, 5))
            self.mapping[key] = combo
        self.matrix_widgets = {}
        if self.mode == "history":
            row = 7
            ttk.Label(self.mapping_frame, text="Mode Tableau : catégorie de chaque colonne contenant un médecin (laisser vide pour les autres)").grid(row=row, column=0, columnspan=4, sticky="w")
            for n, h in enumerate(headers):
                if not h:
                    continue
                try:
                    default = category(h)
                except ValueError:
                    default = ""
                # La date et les colonnes techniques ne sont pas proposées comme types automatiques.
                ttk.Label(self.mapping_frame, text=h).grid(row=row + 1 + (n // 4) * 2, column=n % 4, sticky="w", padx=8)
                combo = ttk.Combobox(self.mapping_frame, values=["", *CATEGORIES], state="readonly", width=26)
                combo.set(default)
                combo.grid(row=row + 2 + (n // 4) * 2, column=n % 4, padx=8)
                self.matrix_widgets[h] = combo

    @guarded
    def prepare(self):
        if not self.sheets:
            raise ValueError("Choisissez un fichier.")
        cols = {key: widget.get() for key, widget in self.mapping.items()}
        rows = self.sheets[self.sheet.get()]
        matrix = {h: w.get() for h, w in self.matrix_widgets.items() if w.get()} if self.kind.get() == "Tableau" else None
        if self.kind.get() == "Tableau" and not matrix:
            raise ValueError("Associez au moins une colonne à une catégorie.")
        doctors = self.app.project.doctors()
        if self.mode == "doctors":
            preview = prepare_doctors(rows, cols, doctors, int(self.header.get()) - 1)
        else:
            preview = prepare_history(rows, cols, doctors, self.app.project.rules(), self.resolutions, matrix, int(self.header.get()) - 1)
        preview.fingerprint = file_fingerprint(self.path, self.mode, self.sheet.get(), {**cols, "matrix": matrix, "header": self.header.get(), "resolutions": self.resolutions})
        self.preview = preview
        already = self.app.project.conn.execute("SELECT 1 FROM imports WHERE fingerprint=?", (preview.fingerprint,)).fetchone()
        if already:
            preview.errors.clear()
            preview.unresolved.clear()
            preview.warnings.append("Ce fichier a déjà été importé avec ces paramètres : aucune écriture supplémentaire.")
        lines = [f"{len(preview.doctors)} médecin(s), {len(preview.records)} garde(s) prêts à importer.", ""]
        lines += [f"{d.id}  {d.name}  coefficient {d.coefficient}  participation {spans_text(d.participation)}" for d in preview.doctors]
        names = {d.id: d.name for d in doctors}
        lines += [f"{r.slot.day}  {r.slot.category}  {r.slot.start or '?'}–{r.slot.end or '?'}  {names[r.doctor_id]}" for r in preview.records]
        lines += ["\nERREURS", *preview.errors, "\nRAPPROCHEMENTS REQUIS", *[f"{k!r} : {len(v)} candidat(s)" for k, v in preview.unresolved.items()], "\nAVERTISSEMENTS", *preview.warnings]
        pairs = conflicts(self.app.project, preview)
        lines += [f"\n{len(pairs)} conflit(s) avec l'historique effectif."]
        show_text(self.info, "\n".join(lines))
        self.confirm.configure(state="normal" if not preview.errors and not preview.unresolved else "disabled")

    @guarded
    def resolve(self):
        if not self.preview or not self.preview.unresolved:
            raise ValueError("Aucun rapprochement en attente. Relancez l'aperçu si besoin.")
        keys = list(self.preview.unresolved)
        doctors = self.app.project.doctors()
        options = {f"{d.name} [{d.id}]": d.id for d in doctors}
        def save(v):
            self.resolutions[v["nom"]] = options[v["ident"]]
            self.prepare()
        Form(self, "Rapprochement explicite", [("nom", "Texte importé", keys[0], keys),
                                                ("ident", "Médecin confirmé", next(iter(options), ""), list(options))], save,
             "Vérifiez l'identité : les homonymes restent des médecins distincts.")

    @guarded
    def commit(self):
        if not self.preview:
            raise ValueError("Préparez l'aperçu.")
        # Empêcher une écriture après changement de colonnes non prévisualisé.
        previous = self.preview.fingerprint
        self.prepare()
        if not self.preview or self.preview.fingerprint != previous:
            raise ValueError("Les paramètres ont changé. Vérifiez le nouvel aperçu puis confirmez à nouveau.")
        policy = {"Bloquer les conflits": "error", "Ignorer les conflits": "ignore", "Remplacer / corriger les conflits": "replace"}[self.policy.get()]
        if messagebox.askyesno("Confirmer l'écriture", "Enregistrer cet import dans le projet ? Une sauvegarde sera créée avant l'écriture.", parent=self):
            result = commit_import(self.app.project, self.preview, policy)
            messagebox.showinfo("Import terminé", f"{result['imported']} enregistré(s), {result['ignored']} ignoré(s).", parent=self)
            self.app.refresh()
            self.destroy()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("GARDAVU — Répartition des gardes")
        self.geometry("1320x880")
        self.minsize(1040, 720)
        self.project = None
        self.plan = None
        self.cancel = None
        self.events = queue.Queue()
        self.busy = False
        style = ttk.Style(self)
        style.theme_use("vista" if "vista" in style.theme_names() else "clam")
        style.configure("TLabel", font=("Segoe UI", 10))
        style.configure("TButton", padding=(10, 5))
        style.configure("Treeview", rowheight=27, font=("Segoe UI", 10))
        bar = ttk.Frame(self, padding=(14, 10))
        bar.pack(fill="x")
        ttk.Label(bar, text="GARDAVU", font=("Segoe UI", 19, "bold")).pack(side="left", padx=(0, 24))
        for label, command in [("Nouveau projet", self.new_project), ("Ouvrir", self.open_project),
                               ("Démonstration fictive", self.demo), ("Sauvegarder / Copier", self.backup),
                               ("Restaurer", self.restore)]:
            ttk.Button(bar, text=label, command=command).pack(side="left", padx=3)
        self.project_label = ttk.Label(self, text="Créez ou ouvrez un fichier .gardavu. Les données restent à l'emplacement choisi.", padding=(18, 5))
        self.project_label.pack(fill="x")
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=14, pady=10)
        self.tabs = {}
        for label in ["Projet et période", "Médecins et absences", "Créneaux et règles", "Historique", "Génération", "Planning", "Équité et exports"]:
            frame = ttk.Frame(self.nb, padding=12)
            self.tabs[label] = frame
            self.nb.add(frame, text=label)
        self.make_project_tab()
        self.make_doctor_tab()
        self.make_rules_tab()
        self.make_history_tab()
        self.make_generation_tab()
        self.make_planning_tab()
        self.make_equity_tab()
        self.status = ttk.Label(self, text="Prêt. Aucun projet ouvert.", padding=(16, 8))
        self.status.pack(fill="x")
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.after(100, self.poll)

    def require_project(self):
        if not self.project:
            raise ValueError("Créez ou ouvrez un projet d'abord.")
        if self.busy:
            raise ValueError("Calcul en cours. Annulez-le avant de modifier les données ou de changer de projet.")

    def make_project_tab(self):
        tab = self.tabs["Projet et période"]
        ttk.Label(tab, text="Préparer une période", font=("Segoe UI", 15, "bold")).pack(anchor="w", pady=(0, 12))
        fields = ttk.Frame(tab)
        fields.pack(fill="x")
        self.start = tk.StringVar(value=add_months(date.today().replace(day=1), 1).isoformat())
        self.months = tk.StringVar(value="6")
        self.end = tk.StringVar(value=period_end(parse_date(self.start.get()), 6).isoformat())
        for n, (label, var, width) in enumerate([("Début inclus (JJ/MM/AAAA ou AAAA-MM-JJ)", self.start, 22),
                                                ("Nombre de mois", self.months, 10), ("Fin incluse", self.end, 22)]):
            ttk.Label(fields, text=label).grid(row=0, column=n, sticky="w", padx=(0, 16))
            ttk.Entry(fields, textvariable=var, width=width).grid(row=1, column=n, sticky="w", padx=(0, 16), pady=6)
        ttk.Button(fields, text="Calculer la fin à partir des mois", command=self.compute_end).grid(row=1, column=3)
        ttk.Label(tab, text="La date de fin saisie fait foi. Convention : jour du mois conservé, ramené au dernier jour si nécessaire ; anniversaire exclu.").pack(anchor="w", pady=8)
        ttk.Button(tab, text="Vérifier les besoins et les charges théoriques", command=self.preview_needs).pack(anchor="w", pady=8)
        self.needs = text_area(tab)
        show_text(self.needs, "1. Saisissez ou importez les médecins.\n2. Distinguez suspension de participation et indisponibilité ponctuelle.\n3. Importez l'historique disponible.\n4. Configurez les horaires de semaine et confirmez l'espacement minimal.\n5. Vérifiez les besoins puis générez.\n\nLe fichier projet SQLite contient des données personnelles et n'est pas chiffré. Partagez-le volontairement. Partager uniquement GARDAVU.exe ne partage pas vos données.")
        self.version_tree = tree(tab, ["État", "Début", "Fin", "Solveur", "Version"], 5)
        self.version_tree.bind("<Double-1>", self.load_plan)
        ttk.Label(tab, text="Double-cliquez une version enregistrée pour l'examiner. Les versions remplacées ne comptent pas dans l'historique effectif.").pack(anchor="w")

    def make_doctor_tab(self):
        tab = self.tabs["Médecins et absences"]
        bar = ttk.Frame(tab)
        bar.pack(fill="x")
        for label, command in [("Ajouter", lambda: self.edit_doctor(False)), ("Modifier", lambda: self.edit_doctor(True)),
                               ("Désactiver à une date", self.deactivate), ("Importer des médecins", lambda: self.import_data("doctors"))]:
            ttk.Button(bar, text=label, command=command).pack(side="left", padx=3)
        ttk.Label(tab, text="Suspension / absence longue : réduit la cible. Indisponibilité ponctuelle : interdit des dates sans réduire la cible.").pack(anchor="w", pady=12)
        self.doctor_tree = tree(tab, ["Médecin", "Coefficient", "Participation", "Suspensions neutralisantes", "Indisponibilités ponctuelles", "Limites total / mois", "Désactivé dès", "Identifiant"])
        self.doctor_tree.bind("<Double-1>", lambda e: self.edit_doctor(True))

    def make_rules_tab(self):
        tab = self.tabs["Créneaux et règles"]
        bar = ttk.Frame(tab)
        bar.pack(fill="x")
        for label, command in [("Paramètres du calcul", self.edit_settings), ("Ajouter un modèle", lambda: self.edit_template(False)),
                               ("Nouvelle version d'un modèle", lambda: self.edit_template(True)),
                               ("Exception à une date", self.date_exception), ("Fêtes / dates particulières", self.holiday_exception)]:
            ttk.Button(bar, text=label, command=command).pack(side="left", padx=2)
        self.rules_info = ttk.Label(tab, text="", wraplength=1180)
        self.rules_info.pack(anchor="w", pady=12)
        self.template_tree = tree(tab, ["Modèle", "Type de jour", "Catégorie", "Début", "Fin", "Effectif", "Effet dès", "Jusqu'au", "Actif"], 10)
        ttk.Label(tab, text="Un férié remplace les créneaux ordinaires. Nuit = 19 h à minuit. Les horaires historiques sont conservés.").pack(anchor="w")
        self.exceptions_info = text_area(tab, 5)

    def make_history_tab(self):
        tab = self.tabs["Historique"]
        bar = ttk.Frame(tab)
        bar.pack(fill="x")
        ttk.Button(bar, text="Importer un historique", command=lambda: self.import_data("history")).pack(side="left")
        ttk.Button(bar, text="Déclarer une couverture connue complète", command=self.edit_coverage).pack(side="left", padx=8)
        ttk.Button(bar, text="Générer les modèles Excel", command=self.templates).pack(side="left")
        self.coverage_label = ttk.Label(tab, text="", wraplength=1180)
        self.coverage_label.pack(anchor="w", pady=10)
        self.history_tree = tree(tab, ["Date", "Médecin", "Catégorie", "Début", "Fin", "Fêtes", "Origine"])

    def make_generation_tab(self):
        tab = self.tabs["Génération"]
        bar = ttk.Frame(tab)
        bar.pack(fill="x")
        ttk.Button(bar, text="Générer la période saisie", command=lambda: self.generate(False)).pack(side="left")
        ttk.Button(bar, text="Régénérer le planning affiché (respecter verrous)", command=lambda: self.generate(True)).pack(side="left", padx=8)
        self.repair = tk.BooleanVar(value=False)
        ttk.Checkbutton(bar, text="Modifier le moins possible", variable=self.repair).pack(side="left")
        ttk.Button(bar, text="Annuler le calcul", command=self.cancel_compute).pack(side="right")
        self.progress = ttk.Progressbar(tab, mode="indeterminate")
        self.progress.pack(fill="x", pady=12)
        self.diagnostics = text_area(tab)
        show_text(self.diagnostics, "Chaque résultat est contrôlé par un validateur métier indépendant.\nOPTIMAL : toutes les étapes sont prouvées optimales.\nFEASIBLE : planning trouvé, optimalité globale non démontrée.\nINFEASIBLE : conflit démontré. UNKNOWN : aucune conclusion dans le temps imparti.\nMODEL_INVALID : modèle ou résultat invalide.\nAucune contrainte impérative n'est assouplie automatiquement.")

    def make_planning_tab(self):
        tab = self.tabs["Planning"]
        bar = ttk.Frame(tab)
        bar.pack(fill="x")
        self.filter_doctor = ttk.Combobox(bar, state="readonly", width=26)
        self.filter_doctor.set("Tous les médecins")
        self.filter_doctor.pack(side="left")
        self.filter_doctor.bind("<<ComboboxSelected>>", lambda e: self.refresh_plan())
        self.filter_category = ttk.Combobox(bar, state="readonly", width=24, values=["Toutes catégories", *CATEGORIES.values()])
        self.filter_category.set("Toutes catégories")
        self.filter_category.pack(side="left", padx=8)
        self.filter_category.bind("<<ComboboxSelected>>", lambda e: self.refresh_plan())
        for label, command in [("Modifier", self.manual), ("Échanger 2 lignes", self.swap), ("Verrouiller / libérer", self.toggle_lock),
                               ("Valider", self.validate_current), ("Archiver", self.archive_current)]:
            ttk.Button(bar, text=label, command=command).pack(side="left", padx=2)
        self.plan_status = ttk.Label(tab, text="Aucun planning", font=("Segoe UI", 13, "bold"))
        self.plan_status.pack(anchor="w", pady=8)
        views = ttk.Notebook(tab)
        views.pack(fill="both", expand=True)
        chronological, monthly = ttk.Frame(views), ttk.Frame(views)
        views.add(chronological, text="Tableau chronologique")
        views.add(monthly, text="Vue mensuelle")
        self.planning_tree = tree(chronological, ["Date", "Jour", "Catégorie", "Horaires", "Médecin", "Verrou", "Poste"])
        self.planning_tree.bind("<Double-1>", lambda e: self.manual())
        monthbar = ttk.Frame(monthly)
        monthbar.pack(fill="x", pady=5)
        self.month_view = ttk.Combobox(monthbar, state="readonly")
        self.month_view.pack(side="left")
        self.month_view.bind("<<ComboboxSelected>>", lambda e: self.draw_month())
        self.month_grid = ttk.Frame(monthly)
        self.month_grid.pack(fill="both", expand=True)

    def make_equity_tab(self):
        tab = self.tabs["Équité et exports"]
        bar = ttk.Frame(tab)
        bar.pack(fill="x")
        ttk.Button(bar, text="Exporter Excel", command=lambda: self.export("xlsx")).pack(side="left")
        ttk.Button(bar, text="Exporter CSV", command=lambda: self.export("csv")).pack(side="left", padx=8)
        ttk.Button(bar, text="Détail du médecin sélectionné", command=self.stats_detail).pack(side="left")
        self.equity_tree = tree(tab, ["Médecin", "Cible", "Attribué", "Écart", "Mois multiples", "Heures", "Espacement min", *CATEGORIES.values(), "Fériés total", "Lun", "Mar", "Mer", "Jeu", "Ven"])
        self.equity_detail = text_area(tab, 8)

    @guarded
    def compute_end(self):
        self.end.set(period_end(parse_date(self.start.get()), int(self.months.get())).isoformat())

    def set_project(self, project):
        if self.project:
            self.project.close()
        self.project = project
        self.plan = None
        period = project.meta("period")
        if period:
            self.start.set(period["start"])
            self.end.set(period["end"])
        self.refresh()

    @guarded
    def new_project(self):
        if self.busy:
            raise ValueError("Annulez le calcul avant de changer de projet.")
        path = filedialog.asksaveasfilename(parent=self, defaultextension=".gardavu", filetypes=[("Projet GARDAVU", "*.gardavu")])
        if path:
            self.set_project(Project(path, create=True))

    @guarded
    def open_project(self):
        if self.busy:
            raise ValueError("Annulez le calcul avant de changer de projet.")
        path = filedialog.askopenfilename(parent=self, filetypes=[("Projet GARDAVU", "*.gardavu")])
        if path:
            if self.project and Path(path).resolve() == self.project.path:
                return
            self.set_project(Project(path))

    @guarded
    def demo(self):
        if self.busy:
            raise ValueError("Annulez le calcul d'abord.")
        path = filedialog.asksaveasfilename(parent=self, title="Créer un projet FICTIF séparé", initialfile="DEMONSTRATION.gardavu", defaultextension=".gardavu")
        if path:
            from .demo import create_demo
            create_demo(path)
            self.set_project(Project(path))

    @guarded
    def backup(self):
        self.require_project()
        path = filedialog.asksaveasfilename(parent=self, title="Copie cohérente du projet (nouveau fichier)", initialfile=self.project.path.stem + "_copie.gardavu", defaultextension=".gardavu")
        if path:
            self.project.backup(path)
            self.status.configure(text=f"Copie sauvegardée : {path}")

    @guarded
    def restore(self):
        if self.busy:
            raise ValueError("Annulez le calcul d'abord.")
        source = filedialog.askopenfilename(parent=self, title="Choisir la sauvegarde à restaurer", filetypes=[("Projet GARDAVU", "*.gardavu")])
        if source:
            dest = filedialog.asksaveasfilename(parent=self, title="Restaurer vers un nouveau fichier", defaultextension=".gardavu")
            if dest:
                Project.restore(source, dest)
                self.set_project(Project(dest))

    @guarded
    def preview_needs(self):
        self.require_project()
        a, b = parse_date(self.start.get()), parse_date(self.end.get())
        slots = generate_slots(a, b, self.project.rules())
        doctors = self.project.doctors()
        targets = calculate_targets(slots, doctors)
        lines = [f"Du {a:%d/%m/%Y} au {b:%d/%m/%Y} inclus", f"{len(slots)} créneaux ; {sum(s.required for s in slots)} affectations nécessaires ; {len(doctors)} médecins enregistrés.", ""]
        for month in sorted({s.day[:7] for s in slots}):
            need = sum(s.required for s in slots if s.day[:7] == month)
            participating = [d for d in doctors if targets[d.id, f"MOIS:{month}"] > 0]
            lines.append(f"{month} : {need} affectations pour {len(participating)} participants. " + ("Certains devront assurer plusieurs gardes." if need > len(participating) else ""))
        lines += ["", "Charges théoriques (les indisponibilités ponctuelles ne les réduisent pas) :"]
        lines += [f"{d.name} : {float(targets[d.id, 'TOTAL']):.3f}" for d in doctors]
        show_text(self.needs, "\n".join(lines))
        self.project.set_meta("period", {"start": a.isoformat(), "end": b.isoformat()})

    @guarded
    def load_plan(self, event=None):
        self.require_project()
        selected = self.version_tree.selection()
        if selected:
            self.plan = next(p for p in self.project.plans() if p.id == selected[0])
            self.start.set(self.plan.start)
            self.end.set(self.plan.end)
            self.refresh_plan()
            self.nb.select(self.tabs["Planning"])

    @guarded
    def edit_doctor(self, existing):
        self.require_project()
        doctors = self.project.doctors()
        if existing:
            selection = self.doctor_tree.selection()
            if not selection:
                raise ValueError("Sélectionnez un médecin.")
            doctor = next(d for d in doctors if d.id == selection[0])
        else:
            doctor = Doctor("")
        fields = [("last", "Nom", doctor.last, None), ("first", "Prénom", doctor.first, None),
                  ("display", "Nom d'affichage facultatif", doctor.display, None),
                  ("coefficient", "Coefficient explicite", doctor.coefficient, None),
                  ("participation", "Participations (une par ligne)", spans_text(doctor.participation), "multiline"),
                  ("suspensions", "Absences longues / suspensions\n(réduisent la cible)", spans_text(doctor.suspensions), "multiline"),
                  ("unavailable", "Indisponibilités ponctuelles\n(ne réduisent pas la cible)", spans_text(doctor.unavailable), "multiline"),
                  ("aliases", "Alias (séparés par ;)", "; ".join(doctor.aliases), None),
                  ("max_total", "Maximum impératif total (vide = aucun)", doctor.max_total, None),
                  ("max_month", "Maximum impératif par mois", doctor.max_month, None),
                  ("deactivated_on", "Désactivation dès (vide = actif)", doctor.deactivated_on, None)]
        def save(v):
            obj = deepcopy(doctor)
            for key in ("last", "first", "display"):
                setattr(obj, key, v[key])
            obj.coefficient = float(v["coefficient"].replace(",", "."))
            for key in ("participation", "suspensions", "unavailable"):
                setattr(obj, key, parse_spans(v[key]))
            obj.aliases = [s.strip() for s in v["aliases"].split(";") if s.strip()]
            obj.max_total = int(v["max_total"]) if v["max_total"] else None
            obj.max_month = int(v["max_month"]) if v["max_month"] else None
            obj.deactivated_on = parse_date(v["deactivated_on"]).isoformat() if v["deactivated_on"] else None
            self.project.save_doctor(obj)
            self.refresh()
        Form(self, "Médecin et disponibilité", fields, save,
             f"Identifiant stable : {doctor.id}\nPériodes : AAAA-MM-JJ..AAAA-MM-JJ (fin vide = sans limite). Un seul jour : répéter la même date. Aucun motif médical demandé.")

    @guarded
    def deactivate(self):
        self.require_project()
        selection = self.doctor_tree.selection()
        if not selection:
            raise ValueError("Sélectionnez un médecin.")
        d = next(d for d in self.project.doctors() if d.id == selection[0])
        when = simpledialog.askstring("Désactiver", "Désactivé dès quelle date incluse ? (JJ/MM/AAAA)", parent=self)
        if when:
            d.deactivated_on = parse_date(when).isoformat()
            self.project.save_doctor(d)
            self.refresh()

    @guarded
    def edit_settings(self):
        self.require_project()
        rules = self.project.rules()
        fields = [("min_gap", "Espacement minimal (jours calendaires)", rules.min_gap, None),
                  ("gap_confirmed", "Confirmer ce choix organisationnel", "Oui" if rules.gap_confirmed else "Non", ["Oui", "Non"]),
                  ("distinct_day", "Deux créneaux d'un même jour interdits", "Oui" if rules.distinct_day else "Non", ["Oui", "Non"]),
                  ("holiday_mode", "Rotation des fêtes", rules.holiday_mode, ["PRIORITAIRE", "STRICT"]),
                  ("holiday_years", "Fenêtre des fêtes (années)", rules.holiday_years, None),
                  ("recent_months", "Équité récente (mois)", rules.recent_months, None),
                  ("weekday_threshold", "Répétition même jour semaine (vide = proportionnel)", rules.weekday_threshold, None),
                  ("max_seconds", "Temps maximal de calcul (secondes)", rules.max_seconds, None),
                  ("seed", "Graine", rules.seed, None), ("workers", "Travailleurs (1 pour tests déterministes)", rules.workers, None)]
        def save(v):
            for key in ("min_gap", "holiday_years", "recent_months", "seed", "workers"):
                setattr(rules, key, int(v[key]))
            for key in ("distinct_day", "gap_confirmed"):
                setattr(rules, key, v[key] == "Oui")
            rules.max_seconds = float(v["max_seconds"])
            rules.weekday_threshold = int(v["weekday_threshold"]) if v["weekday_threshold"] else None
            rules.holiday_mode = v["holiday_mode"]
            rules.check()
            self.project.save_rules(rules)
            self.refresh()
        Form(self, "Contraintes impératives et calcul", fields, save,
             "7 jours est une proposition d'organisation. Les limites individuelles se règlent dans les fiches médecins. PRIORITAIRE permet une répétition avec avertissement ; STRICT l'interdit.")

    @guarded
    def edit_template(self, existing):
        self.require_project()
        rules = self.project.rules()
        selection = self.template_tree.selection()
        if existing and not selection:
            raise ValueError("Sélectionnez un modèle à configurer (par exemple soir).")
        old = rules.templates[int(selection[0])] if existing else Template("nouveau", "SEMAINE", "SEMAINE", None, None)
        fields = [("id", "Identifiant stable du modèle", old.id, None), ("kind", "Type de jour", old.kind, ["SEMAINE", "SAMEDI", "DIMANCHE", "FERIE"]),
                  ("category", "Catégorie principale", old.category, list(CATEGORIES)), ("start", "Début (HH:MM)", old.start, None),
                  ("end", "Fin (HH:MM, minuit = 24:00)", old.end, None), ("required", "Effectif", old.required, None),
                  ("effective", "Prise d'effet incluse", old.effective if not existing else max(date.today().isoformat(), old.effective), None),
                  ("until", "Fin d'effet facultative", old.until, None), ("enabled", "Actif", "Oui" if old.enabled else "Non", ["Oui", "Non"])]
        def save(v):
            t = Template(v["id"], v["kind"], v["category"], v["start"] or None, v["end"] or None,
                         int(v["required"]), parse_date(v["effective"]).isoformat(), parse_date(v["until"]).isoformat() if v["until"] else None, v["enabled"] == "Oui")
            if not t.id:
                raise ValueError("Identifiant requis.")
            if existing and t.id != old.id:
                raise ValueError("Conservez l'identifiant pour une nouvelle version. Utilisez Ajouter pour un nouveau modèle.")
            # Même date d'effet : remplacement explicite de la définition, historique inchangé.
            rules.templates = [x for x in rules.templates if (x.id, x.effective) != (t.id, t.effective)] + [t]
            if t.start and t.end:
                from .domain import Slot
                Slot("controle", t.effective, t.category, t.start, t.end).interval
            self.project.save_rules(rules)
            self.refresh()
        Form(self, "Modèle de créneau daté", fields, save, "Les modèles servent aux générations futures. Les gardes historiques conservent leurs horaires.")

    @guarded
    def date_exception(self):
        self.require_project()
        rules = self.project.rules()
        choices = ["Modifier / ajouter un créneau", "Désactiver toute la date", "Supprimer l'exception"]
        fields = [("date", "Date de l'exception", self.start.get(), None), ("action", "Action", choices[0], choices),
                  ("id", "Identifiant du créneau dans cette exception", "exception-1", None),
                  ("category", "Catégorie", "SEMAINE", list(CATEGORIES)),
                  ("start", "Début HH:MM", "", None), ("end", "Fin HH:MM", "", None),
                  ("required", "Effectif", 1, None)]
        def save(v):
            key = parse_date(v["date"]).isoformat()
            if v["action"] == choices[2]:
                rules.date_exceptions.pop(key, None)
            elif v["action"] == choices[1]:
                rules.date_exceptions[key] = []
            else:
                from .domain import Slot
                Slot("controle", key, v["category"], v["start"], v["end"]).interval
                if int(v["required"]) < 1:
                    raise ValueError("Effectif au moins égal à 1.")
                t = Template(v["id"], "EXCEPTION", v["category"], v["start"], v["end"], int(v["required"]))
                current = rules.date_exceptions.get(key, [])
                rules.date_exceptions[key] = [x for x in current if x["id"] != t.id] + [asdict(t)]
            self.project.save_rules(rules)
            self.refresh()
        Form(self, "Exception à une date", fields, save,
             "L'exception remplace TOUS les modèles ordinaires de la date. Pour deux créneaux, ajoutez successivement deux identifiants différents. Les exceptions existantes sont listées sous les règles.")

    @guarded
    def holiday_exception(self):
        self.require_project()
        rules = self.project.rules()
        def save(v):
            key = parse_date(v["date"]).isoformat()
            if v["action"] == "Supprimer l'exception":
                rules.holiday_exceptions.pop(key, None)
            else:
                rules.holiday_exceptions[key] = {"add": [s.strip().upper() for s in v["add"].split(",") if s.strip()],
                                                 "remove": [s.strip().upper() for s in v["remove"].split(",") if s.strip()]}
            self.project.save_rules(rules)
            self.refresh()
        Form(self, "Calendrier : correction ou date particulière", [
            ("date", "Date", self.start.get(), None), ("action", "Action", "Enregistrer", ["Enregistrer", "Supprimer l'exception"]),
            ("add", "Identifiants à ajouter (virgules)", "", None), ("remove", "Identifiants à retirer (virgules)", "", None)], save,
            "Identifiants stables : NOEL, JOUR_AN, LUNDI_PAQUES, ASCENSION… Une correction de date se fait en retirant l'identifiant à l'ancienne date et en l'ajoutant à la nouvelle. Les 24 et 31 décembre restent ordinaires sans ajout explicite.")

    @guarded
    def edit_coverage(self):
        self.require_project()
        def save(v):
            spans = parse_spans(v["coverage"])
            if any(not s.end for s in spans):
                raise ValueError("Une couverture complète doit avoir une fin explicite.")
            self.project.set_meta("coverage", [asdict(s) for s in spans])
            self.refresh()
        Form(self, "Couverture connue de l'historique", [("coverage", "Périodes intégralement connues", spans_text([Span(**s) for s in self.project.meta("coverage", [])]), "multiline")], save,
             "Ne déclarez une période complète qu'après contrôle de toutes les gardes, coefficients et participations sur cette période. Une simple première/dernière date importée ne prouve pas la couverture. Sinon, laissez vide : rotation et espacement restent utilisés, sans compensation de charge ancienne.")

    @guarded
    def import_data(self, mode):
        self.require_project()
        ImportWizard(self, mode)

    @guarded
    def templates(self):
        folder = filedialog.askdirectory(parent=self, title="Dossier des modèles Excel")
        if folder:
            paths = create_templates(folder)
            messagebox.showinfo("Modèles créés", "\n".join(map(str, paths)), parent=self)

    def external_history(self, plan):
        return [r for r in self.project.history() if not plan.start <= r.slot.day <= plan.end]

    @guarded
    def generate(self, current):
        self.require_project()
        rules = self.project.rules()
        doctors = self.project.doctors()
        if current:
            if not self.plan:
                raise ValueError("Aucun planning à régénérer.")
            plan = deepcopy(self.plan)
        else:
            a, b = parse_date(self.start.get()), parse_date(self.end.get())
            plan = Plan(a.isoformat(), b.isoformat(), generate_slots(a, b, rules))
        # Gardes passées connues : gel explicite, même en réparation.
        existing = self.project.history()
        for s in plan.slots:
            if s.date < date.today():
                known = [r.doctor_id for r in existing if r.slot.id == s.id]
                original = plan.assignments.get(s.id, known)
                if original:
                    plan.locks[s.id] = list(original)
        history = self.external_history(plan)
        complete = self.project.coverage_complete(plan.start, rules.recent_months)
        self.cancel = Cancellation()
        self.busy = True
        self.progress.start(12)
        self.nb.select(self.tabs["Génération"])
        show_text(self.diagnostics, "Calcul en cours… Les contraintes impératives restent inchangées. Vous pouvez annuler et conserver la meilleure solution conforme trouvée.")
        repair = self.repair.get()
        def worker():
            try:
                result = solve(plan, doctors, rules, history, self.cancel, repair, complete,
                               lambda label: self.events.put(("progress", label)))
                self.events.put(("result", result))
            except Exception as exc:
                self.events.put(("error", str(exc)))
        threading.Thread(target=worker, daemon=True, name="gardavu-cp-sat").start()

    def cancel_compute(self):
        if self.cancel:
            self.cancel.cancel()
            self.status.configure(text="Annulation demandée…")

    def poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "progress":
                    self.status.configure(text=f"Calcul : {value}")
                else:
                    self.busy = False
                    self.progress.stop()
                    self.cancel = None
                    if kind == "error":
                        show_text(self.diagnostics, "ERREUR — calcul interrompu\n" + value)
                        self.status.configure(text="Erreur de calcul visible dans Génération.")
                    else:
                        self.plan = value
                        try:
                            self.project.save_draft(value, "generation")
                            self.refresh()
                            show_text(self.diagnostics, self.diagnostic_text())
                            self.status.configure(text=f"Calcul terminé : {value.solver_status}. Brouillon enregistré.")
                        except Exception as exc:
                            show_text(self.diagnostics, f"Échec d'enregistrement du brouillon : {exc}")
        except queue.Empty:
            pass
        self.after(100, self.poll)

    def diagnostic_text(self):
        if not self.plan:
            return "Aucun planning."
        p = self.plan
        report = validate(p, self.project.doctors(), self.project.rules(), self.external_history(p), p.metadata.get("history_complete", False))
        lines = [f"{plan_label(p)} — {p.solver_status}", f"Du {p.start} au {p.end} inclus", f"Durée : {p.metadata.get('elapsed_seconds', '?')} s", "", "CONTRÔLES", *report.errors, *p.metadata.get("errors", []), "", "AVERTISSEMENTS", *report.warnings, "", "OBJECTIFS SUCCESSIFS"]
        lines += [f"{s['objective']} : {s['status']}, valeur {s.get('value', '?')}, borne {s.get('bound', '?')}" for s in p.metadata.get("stages", [])]
        if p.solver_status == "INFEASIBLE":
            lines += ["", "Pistes à examiner sans modification automatique : disponibilités, effectifs, quotas, verrous, espacement et mode STRICT des fêtes. Une cause précise n'est affirmée que si le contrôle correspondant la démontre."]
        return "\n".join(dict.fromkeys(lines))

    def draft_for_edit(self):
        if not self.plan:
            raise ValueError("Aucun planning.")
        if self.plan.state != "BROUILLON":
            self.plan = deepcopy(self.plan)
            self.plan.id = uid()
            self.plan.state = "BROUILLON"
            self.plan.metadata["manual_revision"] = True

    def selected_rows(self, count=None):
        rows = self.planning_tree.selection()
        if not rows or (count and len(rows) != count):
            raise ValueError(f"Sélectionnez {count or 'une ou plusieurs'} ligne(s) du tableau chronologique.")
        return [self.row_meta[r] for r in rows]

    @guarded
    def manual(self):
        self.require_project()
        slot_id, post = self.selected_rows(1)[0]
        s = next(s for s in self.plan.slots if s.id == slot_id)
        if s.date < date.today():
            raise ValueError("Les gardes passées ne sont pas modifiables dans le planning. Corrigez explicitement l'historique via l'assistant d'import si nécessaire.")
        doctors = self.project.doctors()
        options = {f"{d.name} [{d.id}]": d.id for d in doctors}
        options["NON AFFECTÉ"] = ""
        def save(v):
            self.draft_for_edit()
            roster = self.plan.assignments.setdefault(slot_id, [])
            while len(roster) <= post:
                roster.append("")
            old = roster[post]
            if old in self.plan.locks.get(slot_id, []):
                raise ValueError("Libérez d'abord le verrou de cette affectation.")
            roster[post] = options[v["doctor"]]
            self.plan.assignments[slot_id] = [d for d in roster if d]
            self.after_edit("modification_manuelle")
        Form(self, f"Affectation du {s.day}", [("doctor", "Médecin", "NON AFFECTÉ", list(options))], save,
             "La modification reste en brouillon et est immédiatement contrôlée. Un conflit reste visible et bloque la validation.")

    @guarded
    def swap(self):
        self.require_project()
        (a, i), (b, j) = self.selected_rows(2)
        slots = {s.id: s for s in self.plan.slots}
        if slots[a].date < date.today() or slots[b].date < date.today():
            raise ValueError("Échange de gardes passées interdit.")
        ra, rb = self.plan.assignments.get(a, []), self.plan.assignments.get(b, [])
        if i >= len(ra) or j >= len(rb):
            raise ValueError("Les deux gardes doivent être affectées.")
        if ra[i] in self.plan.locks.get(a, []) or rb[j] in self.plan.locks.get(b, []):
            raise ValueError("Libérez d'abord les verrous concernés.")
        self.draft_for_edit()
        ra, rb = self.plan.assignments[a], self.plan.assignments[b]
        ra[i], rb[j] = rb[j], ra[i]
        self.after_edit("echange_manuel")

    @guarded
    def toggle_lock(self):
        self.require_project()
        rows = self.selected_rows()
        self.draft_for_edit()
        for slot_id, post in rows:
            roster = self.plan.assignments.get(slot_id, [])
            if post < len(roster):
                ident = roster[post]
                locks = self.plan.locks.setdefault(slot_id, [])
                if ident in locks:
                    locks.remove(ident)
                else:
                    locks.append(ident)
        self.after_edit("verrouillage")

    def after_edit(self, action):
        report = validate(self.plan, self.project.doctors(), self.project.rules(), self.external_history(self.plan), self.plan.metadata.get("history_complete", False))
        self.plan.solver_status = "FEASIBLE" if report.ok else "MODEL_INVALID"
        self.plan.metadata.update(errors=report.errors, warnings=report.warnings)
        self.plan.metadata["manual_edit"] = True
        self.project.save_draft(self.plan, action)
        self.refresh_plan()
        show_text(self.diagnostics, self.diagnostic_text())

    @guarded
    def validate_current(self):
        self.require_project()
        if not self.plan:
            raise ValueError("Aucun planning à valider.")
        report = validate(self.plan, self.project.doctors(), self.project.rules(), self.external_history(self.plan), self.plan.metadata.get("history_complete", False))
        if report.errors:
            raise ValueError("INCOMPLET OU NON CONFORME — validation bloquée\n" + "\n".join(report.errors[:25]))
        repeats = False
        if report.repeats:
            repeats = messagebox.askyesno("Répétitions de fêtes", "Confirmer explicitement ces répétitions ?\n\n" + "\n".join(report.repeats), parent=self)
            if not repeats:
                return
        inside = any(self.plan.start <= r.slot.day <= self.plan.end for r in self.project.history())
        if inside and not messagebox.askyesno("Remplacer la période", "Cette période possède des gardes effectives. Remplacer la version faisant autorité, avec conservation de la traçabilité ? Les gardes passées doivent rester identiques.", parent=self):
            return
        self.plan = self.project.validate_plan(self.plan, repeats, inside)
        self.refresh()
        self.status.configure(text="Planning VALIDÉ et sauvegardé dans l'historique effectif.")

    @guarded
    def archive_current(self):
        self.require_project()
        if not self.plan:
            raise ValueError("Aucun planning.")
        self.project.archive(self.plan)
        self.refresh()

    @guarded
    def export(self, kind):
        self.require_project()
        if not self.plan:
            raise ValueError("Aucun planning à exporter.")
        report = validate(self.plan, self.project.doctors(), self.project.rules(), self.external_history(self.plan), self.plan.metadata.get("history_complete", False))
        if self.plan.state in ("VALIDE", "ARCHIVE"):
            # L'état historique indique la validation au moment de la création. Les règles actuelles peuvent différer.
            warnings = self.plan.metadata.get("validation_warnings", [])
        else:
            warnings = report.warnings + report.errors
        path = filedialog.asksaveasfilename(parent=self, initialfile=f"GARDAVU_{self.plan.start}_{self.plan.state}.{kind}", defaultextension="." + kind, filetypes=[(kind.upper(), "*." + kind)])
        if path:
            if kind == "xlsx":
                export_excel(path, self.plan, self.project.doctors(), self.external_history(self.plan), warnings)
            else:
                export_csv(path, self.plan, self.project.doctors())
            self.status.configure(text=f"Export {plan_label(self.plan)} : {path}")

    @guarded
    def stats_detail(self):
        self.require_project()
        selected = self.equity_tree.selection()
        if not selected:
            raise ValueError("Sélectionnez un médecin dans le tableau d'équité.")
        row = next(r for r in statistics(self.plan, self.project.doctors(), self.external_history(self.plan)) if r["id"] == selected[0])
        lines = [row["medecin"], "Gardes par mois : " + ", ".join(f"{m} : {n}" for m, n in row["mois"].items()),
                 f"Cible {row['cible']:.3f}, attribué {row['total']}, écart {row['ecart']:+.3f}", "Fêtes et occurrences antérieures connues :"]
        lines += [f"{f['date']} {', '.join(f['fetes'])} : {', '.join(f['precedentes']) or 'aucune occurrence connue'}" for f in row["fetes"]]
        show_text(self.equity_detail, "\n".join(lines))

    def refresh(self):
        if not self.project:
            return
        doctors = self.project.doctors()
        rules = self.project.rules()
        demo = " — DÉMONSTRATION FICTIVE" if self.project.meta("demo") else ""
        self.project_label.configure(text=str(self.project.path) + demo)
        self.title("GARDAVU — " + self.project.path.stem + demo)
        self.doctor_tree.delete(*self.doctor_tree.get_children())
        names = {d.id: d.name for d in doctors}
        self.filter_options = {"Tous les médecins": None, **{f"{d.name} [{d.id[:8]}]": d.id for d in doctors}}
        self.filter_doctor.configure(values=list(self.filter_options))
        for d in sorted(doctors, key=lambda d: d.name.casefold()):
            self.doctor_tree.insert("", "end", iid=d.id, values=(d.name, d.coefficient, spans_text(d.participation).replace("\n", "; "), spans_text(d.suspensions).replace("\n", "; "), spans_text(d.unavailable).replace("\n", "; "), f"{d.max_total if d.max_total is not None else '—'} / {d.max_month if d.max_month is not None else '—'}", d.deactivated_on or "", d.id))
        self.template_tree.delete(*self.template_tree.get_children())
        for n, t in enumerate(rules.templates):
            self.template_tree.insert("", "end", iid=str(n), values=(t.id, t.kind, CATEGORIES.get(t.category, t.category), t.start or "À CONFIGURER", t.end or "À CONFIGURER", t.required, t.effective, t.until or "", "Oui" if t.enabled else "Non"))
        self.rules_info.configure(text=f"Espacement impératif : {rules.min_gap} j ({'confirmé' if rules.gap_confirmed else 'À CONFIRMER'}). Fêtes : {rules.holiday_mode}, fenêtre {rules.holiday_years} ans. Équité récente : {rules.recent_months} mois si couverture complète. Calcul : {rules.max_seconds} s, {rules.workers} travailleur(s).")
        show_text(self.exceptions_info, "Exceptions de créneaux (remplacement de la journée) :\n" + json.dumps(rules.date_exceptions, ensure_ascii=False, indent=2) + "\nExceptions du calendrier :\n" + json.dumps(rules.holiday_exceptions, ensure_ascii=False, indent=2))
        self.history_tree.delete(*self.history_tree.get_children())
        history = self.project.history()
        for r in history:
            self.history_tree.insert("", "end", iid=r.id, values=(r.slot.day, names.get(r.doctor_id, r.doctor_id), CATEGORIES.get(r.slot.category, r.slot.category), r.slot.start or "Inconnu", r.slot.end or "Inconnue", ", ".join(r.slot.holidays), r.source))
        known = self.project.meta("coverage", [])
        self.coverage_label.configure(text=f"{len(history)} affectations effectives. Couverture attestée : " + (" ; ".join(f"{s['start']} au {s['end']}" for s in known) or "non déclarée, historique incomplet") + ". Aucune occurrence connue ne signifie pas « jamais effectué ».")
        self.version_tree.delete(*self.version_tree.get_children())
        for p in self.project.plans():
            self.version_tree.insert("", "end", iid=p.id, values=(p.state, p.start, p.end, p.solver_status, p.id))
        self.refresh_plan()

    def refresh_plan(self):
        if not self.plan or not self.project:
            self.plan_status.configure(text="Aucun planning", foreground="#244454")
            self.planning_tree.delete(*self.planning_tree.get_children())
            self.equity_tree.delete(*self.equity_tree.get_children())
            for child in self.month_grid.winfo_children():
                child.destroy()
            show_text(self.equity_detail, "Générez ou ouvrez une version enregistrée.")
            return
        p = self.plan
        doctors = self.project.doctors()
        display_rules = self.project.rules()
        if p.state != "BROUILLON" and p.metadata.get("doctors_snapshot"):
            doctors = [Doctor.from_dict(d) for d in p.metadata["doctors_snapshot"]]
            display_rules = Rules.from_dict(p.metadata["validated_rules"])
        names = {d.id: d.name for d in doctors}
        try:
            report = validate(p, doctors, display_rules, self.external_history(p), p.metadata.get("history_complete", False))
            errors = report.errors
        except ValueError as exc:
            errors = [str(exc)]
        label = "INCOMPLET / NON CONFORME — NON VALIDÉ" if errors and p.state == "BROUILLON" else plan_label(p)
        self.plan_status.configure(text=f"{label} — {p.start} au {p.end} inclus — {p.solver_status} — {len(errors)} erreur(s)", foreground="#a02020" if errors else "#244454")
        self.planning_tree.delete(*self.planning_tree.get_children())
        self.row_meta = {}
        ident_filter = getattr(self, "filter_options", {}).get(self.filter_doctor.get())
        cat_filter = next((k for k, v in CATEGORIES.items() if v == self.filter_category.get()), None)
        weekdays = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
        for s in p.slots:
            roster = p.assignments.get(s.id, [])
            for post in range(max(s.required, len(roster))):
                ident = roster[post] if post < len(roster) else ""
                if ident_filter and ident_filter != ident or cat_filter and cat_filter != s.category:
                    continue
                iid = str(len(self.row_meta))
                self.row_meta[iid] = (s.id, post)
                self.planning_tree.insert("", "end", iid=iid, values=(s.day, weekdays[s.date.weekday()], CATEGORIES[s.category], f"{s.start or '?'}–{s.end or '?'}", names.get(ident, "NON AFFECTÉ"), "Verrouillée" if ident and ident in p.locks.get(s.id, []) else "", post + 1))
        self.month_view.configure(values=sorted({s.day[:7] for s in p.slots}))
        if self.month_view.get() not in self.month_view["values"]:
            self.month_view.set(p.start[:7])
        self.draw_month()
        self.equity_tree.delete(*self.equity_tree.get_children())
        try:
            for row in statistics(p, doctors, self.external_history(p)):
                self.equity_tree.insert("", "end", iid=row["id"], values=(row["medecin"], f"{row['cible']:.3f}", row["total"], f"{row['ecart']:+.3f}", row["mois_multiples"], row["heures"], row["espacement_min"] if row["espacement_min"] is not None else "—", *[row["categories"].get(c, 0) for c in CATEGORIES], row["feries"], *[row["jours_semaine"].get(n, 0) for n in range(5)]))
        except ValueError as exc:
            show_text(self.equity_detail, str(exc))

    def draw_month(self):
        for child in self.month_grid.winfo_children():
            child.destroy()
        if not self.plan or not self.month_view.get():
            return
        year, month = map(int, self.month_view.get().split("-"))
        names = {d.id: d.name for d in self.project.doctors()}
        if self.plan.state != "BROUILLON" and self.plan.metadata.get("doctors_snapshot"):
            names = {d["id"]: (d["display"] or (d["last"] + " " + d["first"]).strip()) for d in self.plan.metadata["doctors_snapshot"]}
        ident_filter = getattr(self, "filter_options", {}).get(self.filter_doctor.get())
        cat_filter = next((k for k, v in CATEGORIES.items() if v == self.filter_category.get()), None)
        for col, name in enumerate(["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]):
            ttk.Label(self.month_grid, text=name, anchor="center").grid(row=0, column=col, sticky="ew", pady=6)
            self.month_grid.columnconfigure(col, weight=1, uniform="days")
        for row, week in enumerate(calendar.monthcalendar(year, month), 1):
            self.month_grid.rowconfigure(row, weight=1)
            for col, day in enumerate(week):
                if not day:
                    continue
                key = date(year, month, day).isoformat()
                lines = [str(day)]
                for s in self.plan.slots:
                    if s.day == key and (not cat_filter or cat_filter == s.category):
                        roster = [names.get(d, d) for d in self.plan.assignments.get(s.id, []) if not ident_filter or d == ident_filter]
                        if not ident_filter or roster:
                            lines += [f"{s.start} : {', '.join(roster) or 'NON AFFECTÉ'}"]
                ttk.Label(self.month_grid, text="\n".join(lines), relief="solid", padding=6, anchor="nw", wraplength=160).grid(row=row, column=col, sticky="nsew", padx=1, pady=1)

    def close(self):
        if self.busy:
            self.cancel_compute()
            self.status.configure(text="Annulation demandée. Fermez après la fin du calcul pour conserver le brouillon.")
            return
        if self.project:
            self.project.close()
        self.destroy()
