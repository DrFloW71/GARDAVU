"""GARDAVU : planification locale des gardes."""

__version__ = "1.0.0"
