"""Archive portable : logiciel, notices et modèles ; démonstration séparée."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    exe = ROOT / 'dist/GARDAVU.exe'
    paths = [exe, ROOT / 'README.md', ROOT / 'LICENSE', ROOT / 'THIRD_PARTY_NOTICES.md',
             *list((ROOT / 'docs').glob('*.md')), *list((ROOT / 'templates').glob('*.xlsx')),
             *[p for p in (ROOT / 'licenses').rglob('*') if p.is_file()]]
    archive = ROOT / 'dist/GARDAVU-portable.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in paths:
            name = 'GARDAVU.exe' if path == exe else path.relative_to(ROOT).as_posix()
            z.write(path, name)
    source_archive = ROOT / 'dist/GARDAVU-sources.zip'
    source_paths = [*[p for p in ROOT.glob('*') if p.is_file() and p.suffix in ('.py', '.toml', '.txt', '.md', '.spec', '.ps1')], ROOT / 'LICENSE', ROOT / '.gitignore']
    for name in ('gardavu', 'tests', 'scripts', 'docs', 'templates', 'licenses', 'demo'):
        source_paths.extend(p for p in (ROOT / name).rglob('*')
                            if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.lock'))
    with zipfile.ZipFile(source_archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in source_paths:
            z.write(path, path.relative_to(ROOT).as_posix())
    metadata = {}
    for path in (exe, archive, source_archive):
        metadata[path.name] = {'bytes': path.stat().st_size, 'MiB': round(path.stat().st_size / 1048576, 2),
                               'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    (ROOT / 'dist/distribution.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()
