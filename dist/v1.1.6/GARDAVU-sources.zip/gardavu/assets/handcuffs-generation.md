# Visuel des menottes de la barre latérale

Outil : ImageGen intégré, mode génération, fond transparent.
Source : `handcuffs-source.png`, 1448 × 1086 pixels RGBA.
Fichier affiché : `handcuffs-sidebar.png`, 88 × 66 pixels RGBA,
préparé par `scripts/build_sidebar_image.ps1` avec réduction bicubique lissée.

## Prompt final

Use case: product-mockup. Asset type: a realistic isolated product cutout to replace a small handcuffs image in the upper left sidebar of a Windows desktop application. Subject: exactly one pair of genuine stainless steel chain handcuffs, two oval wrist cuffs with the correct substantial double cheek plates, solid rectangular locking housings with small keyholes and pivots, connected by a short chain of two interlocking metal links. Both cuffs closed, clearly separated and recognizable; one slightly lower left and one upper right in a balanced compact diagonal arrangement. Style: photorealistic premium studio product photography, accurate mechanical shapes, brushed silver steel and subtle polished edge highlights, restrained realistic material reflections, slightly oblique top-down view. Composition: the entire pair fully visible, centered, occupying about 88 percent of the canvas, a compact horizontal 4:3 silhouette with generous open holes in the cuffs; no cut off parts. Lighting: broad soft white studio lights, crisp smooth edges, silver highlights bright enough to remain readable on a dark navy application sidebar, no harsh black masses. Background: genuinely transparent alpha, including the open centers of the cuffs and spaces between chain links. Constraints: object only; no text, watermark, logos, frame, background plate, ground shadow, people, hands, keys or other objects. Optimize the broad silhouette and locking bodies to remain recognizable at approximately 88 by 66 display pixels while retaining high resolution fine detail in the source.
