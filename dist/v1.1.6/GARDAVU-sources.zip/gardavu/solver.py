"""CP-SAT, objectifs successifs avec preuve d'optimalité conservée par étape."""
from collections import Counter, defaultdict
from datetime import date
from math import ceil
import threading
import time
import heapq
import hashlib

import ortools
from ortools.sat.python import cp_model

from .calendar import add_months, calendar_months
from .domain import Doctor, Plan, Record, Rules, Slot, dumps
from .targets import calculate_targets, scaled_targets
from .validation import Report, previous_occurrences, validate


class Cancellation:
    def __init__(self):
        self.event = threading.Event()
        self.solver = None

    def cancel(self):
        self.event.set()
        if self.solver is not None:
            self.solver.stop_search()


def candidates(s, doctors, rules, history):
    result = []
    for d in doctors:
        own_history = history.get(d.id, []) if isinstance(history, dict) else [r for r in history if r.doctor_id == d.id]
        if not d.available(s.date):
            continue
        if rules.holiday_mode == "STRICT" and previous_occurrences(d.id, s, own_history, rules.holiday_years):
            continue
        blocked = False
        for r in own_history:
            gap = abs((s.date - r.slot.date).days)
            if s.day != r.slot.day and gap >= rules.min_gap:
                continue
            if gap < rules.min_gap or (s.day == r.slot.day and rules.distinct_day):
                blocked = True
            if s.day == r.slot.day and (not s.interval or not r.slot.interval):
                blocked = True
            elif s.interval and r.slot.interval and max(s.interval[0], r.slot.interval[0]) < min(s.interval[1], r.slot.interval[1]):
                blocked = True
        if not blocked:
            result.append(d.id)
    return result


def preflight(plan, doctors, rules, history):
    errors = []
    if len({d.id for d in doctors}) != len(doctors) or len({s.id for s in plan.slots}) != len(plan.slots):
        errors.append("Identifiants dupliqués dans les données.")
    try:
        rules.check()
        for d in doctors:
            d.check()
        calculate_targets(plan.slots, doctors)
    except ValueError as exc:
        errors.append(str(exc))
    allowed = {}
    by_doctor = defaultdict(list)
    for record in history:
        by_doctor[record.doctor_id].append(record)
    for s in plan.slots:
        if not s.interval:
            errors.append(f"{s.day} : horaires incomplets.")
        ids = candidates(s, doctors, rules, by_doctor)
        allowed[s.id] = ids
        if len(ids) < s.required:
            available = sum(d.available(s.date) for d in doctors)
            reason = "Indisponibilités ou périodes de participation."
            if available >= s.required:
                reason = "Espacement / chevauchement avec l'historique ou interdiction stricte de fête."
            errors.append(f"{s.day} {s.category} : {s.required} nécessaire(s), {len(ids)} candidat(s). {reason}")
        locks = plan.locks.get(s.id, [])
        if len(set(locks)) != len(locks) or len(locks) > s.required or not set(locks).issubset(ids):
            errors.append(f"Verrouillages contradictoires : {s.day} {s.category}.")
    if set(plan.locks) - set(allowed):
        errors.append("Verrouillage d'un créneau inexistant.")
    required = sum(s.required for s in plan.slots)
    if sum(d.max_total if d.max_total is not None else required for d in doctors) < required:
        errors.append("La somme des quotas totaux impératifs ne couvre pas les besoins.")
    for month in {s.day[:7] for s in plan.slots}:
        need = sum(s.required for s in plan.slots if s.day[:7] == month)
        if sum(d.max_month if d.max_month is not None else need for d in doctors) < need:
            errors.append(f"{month} : le quota mensuel maximal ne permet pas de couvrir les besoins.")
    # Les conflits entre verrous sont contrôlés sans lancer le modèle.
    locked_plan = Plan(plan.start, plan.end, plan.slots, dict(plan.locks), dict(plan.locks))
    lock_report = validate(locked_plan, doctors, rules, history)
    errors.extend(e for e in lock_report.errors if "requis," not in e)
    return list(dict.fromkeys(errors)), allowed


def solve(plan: Plan, doctors: list[Doctor], rules: Rules, history: list[Record],
          cancel: Cancellation | None = None, minimize_changes=False,
          history_complete=False, progress=None) -> Plan:
    started = time.monotonic()
    cancel = cancel or Cancellation()
    # Une nouvelle version reste toujours un brouillon.
    result = Plan(plan.start, plan.end, plan.slots, locks=plan.locks.copy())
    result.metadata = {"rules": __import__("json").loads(dumps(rules)), "ortools": ortools.__version__,
                       "history_complete": history_complete, "history_records": len(history),
                       "stages": [], "seed": rules.seed, "workers": rules.workers}
    result.metadata["history_sha256"] = hashlib.sha256("\n".join(sorted(dumps(r) for r in history)).encode("utf-8")).hexdigest()
    errors, allowed = preflight(plan, doctors, rules, history)
    if errors:
        result.solver_status = "INFEASIBLE"
        result.metadata["errors"] = errors
        return result
    if cancel.event.is_set():
        result.metadata["errors"] = ["Calcul annulé avant recherche ; aucune conclusion."]
        return result
    model = cp_model.CpModel()
    x = {(d.id, s.id): model.new_bool_var(f"x{di}_{si}")
         for di, d in enumerate(doctors) for si, s in enumerate(plan.slots) if d.id in allowed[s.id]}
    for s in plan.slots:
        model.add(sum(x[d, s.id] for d in allowed[s.id]) == s.required)
        for d in plan.locks.get(s.id, []):
            model.add(x[d, s.id] == 1)
    total_need = sum(s.required for s in plan.slots)
    # Cliques de dates : somme <= 1 pour une fenêtre de min_gap jours.
    # Cela exprime exactement l'espacement avec bien moins de contraintes
    # qu'une interdiction pour chaque paire de gardes.
    by_day = defaultdict(list)
    for s in plan.slots:
        by_day[s.day].append(s)
    chronological_days = sorted(by_day)
    cliques = []
    if rules.min_gap > 0:
        for key in chronological_days:
            day = date.fromisoformat(key)
            cliques.append([s.id for other in chronological_days
                            if 0 <= (date.fromisoformat(other) - day).days < rules.min_gap
                            for s in by_day[other]])
    elif rules.distinct_day:
        cliques = [[s.id for s in by_day[key]] for key in chronological_days]
    for d in doctors:
        owned = [s for s in plan.slots if (d.id, s.id) in x]
        if d.max_total is not None:
            model.add(sum(x[d.id, s.id] for s in owned) <= d.max_total)
        for month in {s.day[:7] for s in owned}:
            if d.max_month is not None:
                model.add(sum(x[d.id, s.id] for s in owned if s.day[:7] == month) <= d.max_month)
        for clique in cliques:
            variables = [x[d.id, sid] for sid in clique if (d.id, sid) in x]
            if len(variables) > 1:
                model.add_at_most_one(variables)
        if rules.min_gap == 0 and not rules.distinct_day:
            for group in by_day.values():
                for i, a in enumerate(group):
                    for b in group[i + 1:]:
                        if ((d.id, a.id) in x and (d.id, b.id) in x
                                and max(a.interval[0], b.interval[0]) < min(a.interval[1], b.interval[1])):
                            model.add_at_most_one([x[d.id, a.id], x[d.id, b.id]])
    objectives = []
    if minimize_changes:
        keep = [1 - x[d, s.id] for s in plan.slots for d in plan.assignments.get(s.id, [])
                if (d, s.id) in x and s.date >= date.today()]
        objectives.append(("Modifications futures (mode réparation)", sum(keep)))
    repeated = []
    recency_bound = total_need * (rules.holiday_years * 366 + 1)
    for d in doctors:
        for s in plan.slots:
            if (d.id, s.id) in x:
                prior = previous_occurrences(d.id, s, history, rules.holiday_years)
                if prior:
                    age = (s.date - max(r.slot.date for r in prior)).days
                    repeated.append((recency_bound + 1 + max(0, rules.holiday_years * 366 - age)) * x[d.id, s.id])
    objectives.append(("Rotation des fêtes", sum(repeated)))
    targets = calculate_targets(plan.slots, doctors)
    # Compensation récente uniquement quand l'intégralité de la fenêtre est attestée.
    corrections = defaultdict(int)
    if history_complete:
        lower = add_months(__import__("datetime").date.fromisoformat(plan.start), -rules.recent_months)
        recent = [r for r in history if lower <= r.slot.date < __import__("datetime").date.fromisoformat(plan.start)]
        from dataclasses import replace
        actual_staffing = Counter(r.slot.id for r in recent)
        unique = {r.slot.id: replace(r.slot, required=actual_staffing[r.slot.id]) for r in recent}
        old_targets = calculate_targets(list(unique.values()), doctors) if recent else {}
        for d in doctors:
            for key in ("TOTAL", *[f"CAT:{c}" for c in {s.category for s in plan.slots}], "FERIES"):
                actual = sum(r.doctor_id == d.id and (key == "TOTAL" or key == f"CAT:{r.slot.category}"
                             or (key == "FERIES" and r.slot.category.startswith("FERIE"))) for r in recent)
                corrections[d.id, key] = round((actual - old_targets.get((d.id, key), 0)) * 1000)
    counters = defaultdict(list)
    slot_map = {s.id: s for s in plan.slots}
    for (ident, slot_id), var in x.items():
        s = slot_map[slot_id]
        for key in ("TOTAL", f"MOIS:{s.day[:7]}", f"CAT:{s.category}"):
            counters[ident, key].append(var)
        if s.category.startswith("FERIE"):
            counters[ident, "FERIES"].append(var)
    deviations = defaultdict(list)
    hint_aux = []
    integer_targets = {}
    keys = sorted({key for ident, key in targets})
    for key in keys:
        ints = scaled_targets({d.id: targets[d.id, key] for d in doctors}, salt=f"{plan.start}:{plan.end}:{key}")
        integer_targets.update({(ident, key): value for ident, value in ints.items()})
        key_deviations = []
        for i, d in enumerate(doctors):
            correction = corrections[d.id, key]
            bound = total_need * 1000 + abs(correction) + abs(ints[d.id]) + 1
            dev = model.new_int_var(0, bound, f"dev{len(deviations)}_{key}_{i}")
            model.add_abs_equality(dev, 1000 * sum(counters[d.id, key]) - ints[d.id] + correction)
            hint_aux.append((dev, counters[d.id, key], 1000, -ints[d.id] + correction, "abs"))
            group = "Charge globale" if key == "TOTAL" else "Charge mensuelle" if key.startswith("MOIS:") else "Catégories"
            deviations[group].append(dev)
            key_deviations.append(dev)
        # Borne inférieure exacte du partage entier sans contraintes de dates.
        # Allocation convexe par coûts marginaux ; coupe redondante, jamais un
        # plafond d'équité imposé quand les disponibilités rendent la cible impossible.
        need = sum(s.required for s in plan.slots if key == "TOTAL" or key == f"MOIS:{s.day[:7]}"
                   or key == f"CAT:{s.category}" or (key == "FERIES" and s.category.startswith("FERIE")))
        offsets = {d.id: -ints[d.id] + corrections[d.id, key] for d in doctors}
        counts = Counter()
        baseline = sum(abs(value) for value in offsets.values())
        heap = [(abs(1000 + value) - abs(value), ident) for ident, value in offsets.items()]
        heapq.heapify(heap)
        for _ in range(need):
            delta, ident = heapq.heappop(heap)
            baseline += delta
            counts[ident] += 1
            value = 1000 * counts[ident] + offsets[ident]
            heapq.heappush(heap, (abs(value + 1000) - abs(value), ident))
        model.add(sum(key_deviations) >= baseline)
    for label in ("Charge globale", "Catégories", "Charge mensuelle"):
        objectives.append((label, sum(deviations[label])))
    weekday_cost = []
    threshold = rules.weekday_threshold or max(1, ceil(calendar_months(date.fromisoformat(plan.start), date.fromisoformat(plan.end)) / 3))
    for i, d in enumerate(doctors):
        for w in range(5):
            variables = [x[d.id, s.id] for s in plan.slots if (d.id, s.id) in x and s.category == "SEMAINE" and s.date.weekday() == w]
            count = sum(variables)
            repeat = model.new_int_var(0, total_need, f"rep{i}_{w}")
            excess = model.new_int_var(0, total_need, f"exc{i}_{w}")
            model.add_max_equality(repeat, [0, count - 1])
            model.add_max_equality(excess, [0, count - threshold])
            hint_aux.extend([(repeat, variables, 1, -1, "max"), (excess, variables, 1, -threshold, "max")])
            weekday_cost.append((total_need + 1) * excess + repeat)
    objectives.append(("Diversité lundi–vendredi", sum(weekday_cost)))
    # Régularité à l'échelle des quinzaines, sous les objectifs précédents.
    regularity = []
    anchor = date.fromisoformat(plan.start)
    for i, d in enumerate(doctors):
        groups = defaultdict(list)
        for s in plan.slots:
            if (d.id, s.id) in x:
                groups[(s.date - anchor).days // 14].append(x[d.id, s.id])
        for block, variables in groups.items():
            excess = model.new_int_var(0, total_need, f"reg{i}_{block}")
            model.add_max_equality(excess, [0, sum(variables) - 1])
            hint_aux.append((excess, variables, 1, -1, "max"))
            regularity.append(excess)
    objectives.append(("Régularité par quinzaine", sum(regularity)))
    # Amorçage seulement : la recherche CP-SAT et le contrôle indépendant restent
    # obligatoires. Une heuristique qui échoue n'est jamais une preuve d'impossibilité.
    hint_assignments = defaultdict(list)
    hint_counts = Counter()
    for s in plan.slots:
        for ident in plan.locks.get(s.id, []):
            hint_assignments[s.id].append(ident)
            hint_counts[ident] += 1
    hint_ok = True
    for s in plan.slots:
        while len(hint_assignments[s.id]) < s.required:
            eligible = []
            for ident in allowed[s.id]:
                if ident in hint_assignments[s.id]:
                    continue
                owned = [slot_map[sid] for sid, ids in hint_assignments.items() if ident in ids]
                if any(abs((s.date - other.date).days) < rules.min_gap
                       or (s.day == other.day and rules.distinct_day)
                       or max(s.interval[0], other.interval[0]) < min(s.interval[1], other.interval[1]) for other in owned):
                    continue
                doc = next(d for d in doctors if d.id == ident)
                if doc.max_total is not None and hint_counts[ident] >= doc.max_total:
                    continue
                if doc.max_month is not None and sum(o.day[:7] == s.day[:7] for o in owned) >= doc.max_month:
                    continue
                eligible.append(ident)
            if not eligible:
                hint_ok = False
                break
            def hint_key(ident):
                owned = [slot_map[sid] for sid, ids in hint_assignments.items() if ident in ids]
                return (bool(previous_occurrences(ident, s, history, rules.holiday_years)),
                        (hint_counts[ident] + corrections[ident, "TOTAL"] / 1000) / max(integer_targets[ident, "TOTAL"] / 1000, .001),
                        sum(o.category == s.category for o in owned),
                        sum(o.day[:7] == s.day[:7] for o in owned), ident)
            chosen = min(eligible, key=hint_key)
            hint_assignments[s.id].append(chosen)
            hint_counts[chosen] += 1
        if not hint_ok:
            break
    if hint_ok:
        hint_numbers = {}
        for (ident, sid), variable in x.items():
            number = int(ident in hint_assignments[sid])
            hint_numbers[variable.index] = number
            model.add_hint(variable, number)
        for variable, inputs, factor, offset, operation in hint_aux:
            number = factor * sum(hint_numbers[v.index] for v in inputs) + offset
            model.add_hint(variable, abs(number) if operation == "abs" else max(0, number))
    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = rules.workers
    solver.parameters.random_seed = rules.seed
    # Le modèle est déjà borné et utilise des cliques. Éviter un presolve coûteux
    # permet d'accepter immédiatement l'amorçage complet puis de l'améliorer.
    solver.parameters.cp_model_presolve = False
    cancel.solver = solver
    proof = True
    found = False
    try:
        for index, (label, objective) in enumerate(objectives):
            remaining = rules.max_seconds - (time.monotonic() - started)
            if remaining <= 0 or cancel.event.is_set():
                proof = False
                break
            if progress:
                progress(label)
            if isinstance(objective, int):
                result.metadata["stages"].append({"objective": label, "status": "OPTIMAL", "value": objective, "bound": objective})
                continue
            model.minimize(objective)
            # La première recherche doit pouvoir absorber le presolve. Un UNKNOWN
            # initial n'épuise pas artificiellement un sixième du budget total.
            solver.parameters.max_time_in_seconds = max(.001, remaining * .55 if not found else remaining / (len(objectives) - index))
            status = solver.solve(model)
            status_name = solver.status_name(status)
            stage = {"objective": label, "status": status_name}
            result.metadata["stages"].append(stage)
            if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
                found = True
                result.assignments = {s.id: [d for d in allowed[s.id] if solver.value(x[d, s.id])] for s in plan.slots}
                score = round(solver.objective_value)
                stage.update(value=score, bound=solver.best_objective_bound)
                proof = proof and status == cp_model.OPTIMAL
                # Un objectif seulement réalisable est figé à sa borne supérieure trouvée,
                # jamais annoncé comme optimal. Les priorités déjà obtenues ne se dégradent pas.
                model.add(objective <= score)
                model.clear_hints()
                for variable in [*x.values(), *[spec[0] for spec in hint_aux]]:
                    model.add_hint(variable, solver.value(variable))
            else:
                proof = False
                if not found:
                    result.solver_status = status_name
                if status == cp_model.MODEL_INVALID:
                    result.metadata["errors"] = [solver.solution_info()]
                elif status == cp_model.INFEASIBLE:
                    result.metadata["errors"] = ["Conflit global démontré entre contraintes impératives. Examiner espacement, quotas et verrous ; aucune règle n'a été assouplie. La cause précise n'est pas isolée."]
                break
    finally:
        cancel.solver = None
    result.metadata.update(elapsed_seconds=round(time.monotonic() - started, 3), cancelled=cancel.event.is_set(), weekday_threshold=threshold)
    if found:
        result.solver_status = "OPTIMAL" if proof and len(result.metadata["stages"]) == len(objectives) else "FEASIBLE"
        report = validate(result, doctors, rules, history, history_complete)
        result.metadata.update(errors=report.errors, warnings=report.warnings)
        if report.errors:
            result.solver_status = "MODEL_INVALID"
    else:
        result.metadata.setdefault("errors", ["Aucune solution trouvée dans la limite de calcul (UNKNOWN). Cela ne démontre pas une impossibilité."])
    return result
