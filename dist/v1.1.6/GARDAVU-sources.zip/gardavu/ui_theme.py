"""Palette et dialogues communs, sans modification du thème de Windows."""
from __future__ import annotations

import ctypes
import sys
import tkinter as tk
from tkinter import ttk

PALETTES = {
    "light": dict(bg="#f2f5fa", surface="#ffffff", field="#ffffff", alt="#f3f7fb",
                  text="#183047", muted="#52687e", border="#ccd7e2", accent="#0f6784",
                  hover="#09536c", selected="#d7edf7", selected_text="#153b51",
                  nav="#142e43", nav_hover="#203f57", nav_selected="#285872", nav_muted="#b8cbda",
                  danger="#a51e37", danger_bg="#fff0f2", warning="#805400", warning_bg="#fff3da",
                  disabled="#e7ecf2", success="#166b46"),
    "dark": dict(bg="#101925", surface="#192638", field="#111d2d", alt="#1e2e43",
                 text="#edf4fc", muted="#b6c7d9", border="#3b4e65", accent="#0f6784",
                 hover="#09536c", selected="#285872", selected_text="#f4faff",
                 nav="#0c1521", nav_hover="#1a3045", nav_selected="#285872", nav_muted="#b8cbda",
                 danger="#ff9aa7", danger_bg="#442431", warning="#fbd38a", warning_bg="#48381f",
                 disabled="#263548", success="#8de0b7"),
}


def theme_for(widget):
    while widget is not None:
        if hasattr(widget, "theme") and isinstance(widget.theme, ThemeController):
            return widget.theme
        widget = getattr(widget, "master", None)
    return None


class ThemeController:
    def __init__(self, root, mode="light"):
        self.root = root
        self.style = ttk.Style(root)
        self.style.theme_use("clam")
        self.mode = mode
        self.colors = PALETTES[mode]

    def apply(self, mode=None):
        if mode is not None:
            if mode not in PALETTES:
                raise ValueError("Thème inconnu : choisir Clair ou Sombre.")
            self.mode = mode
        c = self.colors = PALETTES[self.mode]
        s = self.style
        s.configure(".", font=("Segoe UI", 10), background=c["bg"], foreground=c["text"],
                    bordercolor=c["border"], lightcolor=c["border"], darkcolor=c["border"],
                    troughcolor=c["bg"], focuscolor=c["accent"])
        s.configure("TFrame", background=c["bg"])
        s.configure("Card.TFrame", background=c["surface"])
        s.configure("Nav.TFrame", background=c["nav"])
        s.configure("TLabel", background=c["bg"], foreground=c["text"])
        s.configure("Muted.TLabel", foreground=c["muted"])
        s.configure("Title.TLabel", font=("Segoe UI", 21, "bold"))
        s.configure("Section.TLabel", font=("Segoe UI", 12, "bold"))
        s.configure("Danger.TLabel", foreground=c["danger"], font=("Segoe UI", 11, "bold"))
        s.configure("Warning.TLabel", foreground=c["warning"], wraplength=950)
        s.configure("Nav.TLabel", background=c["nav"], foreground="#ffffff")
        s.configure("Brand.TLabel", background=c["nav"], foreground="#ffffff", font=("Segoe UI", 20, "bold"))
        s.configure("NavMuted.TLabel", background=c["nav"], foreground=c["nav_muted"])
        s.configure("Status.TLabel", background=c["surface"], foreground=c["muted"], padding=(18, 9))
        s.configure("Empty.TLabel", background=c["surface"], foreground=c["muted"], padding=15)
        s.configure("Calendar.TFrame", background=c["surface"], bordercolor=c["border"], borderwidth=1, relief="solid")
        s.configure("Calendar.TLabel", background=c["surface"], foreground=c["text"], font=("Segoe UI", 9))
        s.configure("CalendarDay.TButton", background=c["surface"], foreground=c["text"], padding=(3, 2), font=("Segoe UI", 10, "bold"))
        s.configure("TButton", padding=(12, 8), background=c["surface"], foreground=c["text"],
                    borderwidth=1, bordercolor=c["border"], lightcolor=c["surface"], darkcolor=c["surface"], relief="flat")
        s.configure("Info.TButton", padding=(5, 4), font=("Segoe UI Symbol", 13), foreground=c["muted"])
        s.map("TButton", background=[("disabled", c["disabled"]), ("active", c["selected"])],
              foreground=[("disabled", c["muted"])], bordercolor=[("focus", c["accent"])])
        s.configure("Accent.TButton", background=c["accent"], foreground="#ffffff", font=("Segoe UI", 10, "bold"),
                    bordercolor=c["accent"], lightcolor=c["accent"], darkcolor=c["accent"])
        s.map("Accent.TButton", background=[("disabled", c["disabled"]), ("active", c["hover"])],
              foreground=[("disabled", c["muted"]), ("!disabled", "#ffffff")])
        s.configure("Danger.TButton", foreground=c["danger"])
        s.configure("TMenubutton", padding=(12, 8), background=c["surface"], foreground=c["text"], borderwidth=1)
        s.map("TMenubutton", background=[("active", c["selected"])])
        for name in ("TEntry", "TCombobox", "TSpinbox"):
            s.configure(name, fieldbackground=c["field"], background=c["surface"], foreground=c["text"],
                        insertcolor=c["text"], arrowcolor=c["text"], padding=7, borderwidth=1,
                        selectbackground=c["selected"], selectforeground=c["selected_text"], bordercolor=c["border"])
            s.map(name, fieldbackground=[("disabled", c["disabled"]), ("readonly", c["field"])],
                  foreground=[("disabled", c["muted"]), ("readonly", c["text"])], bordercolor=[("focus", c["accent"])])
        for name in ("TCheckbutton", "TRadiobutton"):
            s.configure(name, background=c["bg"], foreground=c["text"], padding=(5, 6), indicatorbackground=c["field"])
            s.map(name, background=[("active", c["bg"])], foreground=[("disabled", c["muted"])],
                  indicatorbackground=[("selected", c["accent"]), ("!selected", c["field"])])
        s.layout("Nav.TRadiobutton", [("Radiobutton.padding", {"sticky": "nswe", "children": [
            ("Radiobutton.label", {"sticky": "nswe"})]})])
        s.configure("Nav.TRadiobutton", padding=(15, 12), background=c["nav"], foreground=c["nav_muted"],
                    font=("Segoe UI", 10, "bold"), anchor="w", relief="flat")
        s.map("Nav.TRadiobutton", background=[("selected", c["nav_selected"]), ("active", c["nav_hover"])],
              foreground=[("selected", "#ffffff"), ("active", "#ffffff")])
        s.configure("TNotebook", background=c["bg"], borderwidth=0, tabmargins=(0, 3, 0, 0))
        s.configure("TNotebook.Tab", padding=(16, 10), background=c["surface"], foreground=c["muted"])
        s.map("TNotebook.Tab", background=[("selected", c["selected"])], foreground=[("selected", c["text"])])
        s.layout("Workspace.TNotebook.Tab", [])
        s.configure("Workspace.TNotebook", background=c["bg"], borderwidth=0, tabmargins=0)
        s.configure("Treeview", rowheight=33, font=("Segoe UI", 10), background=c["surface"], fieldbackground=c["surface"],
                    foreground=c["text"], borderwidth=0, lightcolor=c["border"], darkcolor=c["border"])
        s.map("Treeview", background=[("selected", c["selected"])], foreground=[("selected", c["selected_text"])])
        s.configure("Treeview.Heading", padding=(10, 11), background=c["alt"], foreground=c["text"],
                    font=("Segoe UI", 10, "bold"), relief="flat", borderwidth=0)
        s.map("Treeview.Heading", background=[("active", c["selected"])])
        s.configure("TLabelframe", background=c["bg"], bordercolor=c["border"], borderwidth=1, relief="solid")
        s.configure("TLabelframe.Label", background=c["bg"], foreground=c["text"], font=("Segoe UI", 10, "bold"))
        for name in ("Vertical.TScrollbar", "Horizontal.TScrollbar"):
            s.configure(name, background=c["border"], troughcolor=c["bg"], arrowcolor=c["muted"], borderwidth=0,
                        lightcolor=c["border"], darkcolor=c["border"], arrowsize=13)
            s.map(name, background=[("active", c["muted"])])
        s.configure("TProgressbar", background=c["accent"], troughcolor=c["surface"], borderwidth=0, thickness=8)
        self.root.option_add("*TCombobox*Listbox.background", c["field"])
        self.root.option_add("*TCombobox*Listbox.foreground", c["text"])
        self.root.option_add("*TCombobox*Listbox.selectBackground", c["selected"])
        self.root.option_add("*TCombobox*Listbox.selectForeground", c["selected_text"])
        self.apply_widgets(self.root)

    def apply_widgets(self, widget):
        c = self.colors
        if isinstance(widget, (tk.Tk, tk.Toplevel, tk.Canvas)):
            widget.configure(background=c["bg"])
        if isinstance(widget, (tk.Tk, tk.Toplevel)):
            self.dark_titlebar(widget)
        elif isinstance(widget, tk.Text):
            widget.configure(background=c["field"], foreground=c["text"], insertbackground=c["text"],
                             selectbackground=c["selected"], selectforeground=c["selected_text"], relief="flat", borderwidth=0,
                             highlightthickness=1, highlightbackground=c["border"], highlightcolor=c["accent"])
        elif isinstance(widget, tk.Menu):
            widget.configure(background=c["surface"], foreground=c["text"], activebackground=c["selected"],
                             activeforeground=c["selected_text"], disabledforeground=c["muted"], relief="flat", borderwidth=1)
        elif isinstance(widget, ttk.Treeview):
            widget.tag_configure("row_even", background=c["surface"])
            widget.tag_configure("row_odd", background=c["alt"])
            widget.tag_configure("attention", background=c["warning_bg"], foreground=c["warning"])
        elif isinstance(widget, ttk.Button) and not widget.cget("style"):
            label = str(widget.cget("text"))
            if label in ("Nouveau projet", "Configurer le créneau", "Générer la période saisie", "Valider", "Enregistrer", "Exporter Excel", "4. Confirmer l'import"):
                widget.configure(style="Accent.TButton")
            elif label == "Annuler le calcul":
                widget.configure(style="Danger.TButton")
        for child in widget.winfo_children():
            self.apply_widgets(child)
        if hasattr(widget, "_schedule") and hasattr(widget, "reflow"):
            widget._schedule()

    def dark_titlebar(self, widget):
        if sys.platform != "win32":
            return
        try:
            handle = int(widget.wm_frame(), 0)
            value = ctypes.c_int(self.mode == "dark")
            set_attribute = ctypes.windll.dwmapi.DwmSetWindowAttribute
            set_attribute.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
            set_attribute(handle, 20, ctypes.byref(value), ctypes.sizeof(value))
        except (OSError, ValueError, tk.TclError):
            # L'apparence de la barre native ne conditionne pas le thème du contenu.
            pass


class ThemedMessages:
    """Confirmation et erreurs dans le même thème que le projet."""
    def _show(self, title, message, parent=None, question=False, error=False, **kwargs):
        parent = parent or tk._default_root
        if parent is None:
            from tkinter import messagebox
            return (messagebox.askyesno if question else messagebox.showerror if error else messagebox.showinfo)(title, message)
        dialog = tk.Toplevel(parent)
        dialog.title(title)
        dialog.transient(parent.winfo_toplevel())
        result = {"value": False}
        body = ttk.Frame(dialog, padding=22)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=title, style="Danger.TLabel" if error else "Section.TLabel", wraplength=620).pack(anchor="w", pady=(0, 12))
        content = ttk.Frame(body)
        content.pack(fill="both", expand=True)
        text = tk.Text(content, wrap="word", width=74, height=min(15, max(3, len(str(message)) // 78 + str(message).count("\n") + 1)),
                       font=("Segoe UI", 10), padx=12, pady=10)
        text.insert("1.0", str(message))
        text.configure(state="disabled")
        text.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(content, command=text.yview)
        scroll.pack(side="right", fill="y")
        text.configure(yscrollcommand=scroll.set)
        actions = ttk.Frame(body)
        actions.pack(fill="x", pady=(16, 0))
        def answer(value):
            result["value"] = value
            dialog.destroy()
        if question:
            ttk.Button(actions, text="Non", command=lambda: answer(False)).pack(side="right", padx=(8, 0))
        accept = ttk.Button(actions, text="Oui" if question else "Fermer", style="Accent.TButton", command=lambda: answer(True))
        accept.pack(side="right")
        dialog.bind("<Escape>", lambda event: answer(False))
        def enter(event):
            focused = dialog.focus_get()
            if isinstance(focused, ttk.Button):
                focused.invoke()
            else:
                answer(True)
            return "break"
        dialog.bind("<Return>", enter)
        theme = theme_for(parent)
        if theme:
            theme.apply_widgets(dialog)
        dialog.update_idletasks()
        width, height = dialog.winfo_reqwidth(), dialog.winfo_reqheight()
        dialog.geometry(f"+{max(0, parent.winfo_rootx() + (parent.winfo_width() - width) // 2)}+{max(0, parent.winfo_rooty() + (parent.winfo_height() - height) // 2)}")
        previous_grab = parent.grab_current()
        dialog.grab_set()
        accept.focus_set()
        parent.wait_window(dialog)
        if previous_grab is not None and previous_grab.winfo_exists():
            previous_grab.grab_set()
        return result["value"]

    def showerror(self, title, message, **kwargs):
        return self._show(title, message, error=True, **kwargs)

    def showinfo(self, title, message, **kwargs):
        return self._show(title, message, **kwargs)

    def askyesno(self, title, message, **kwargs):
        return self._show(title, message, question=True, **kwargs)


messagebox = ThemedMessages()
