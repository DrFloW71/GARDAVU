"""Données synthétiques internes aux tests et aux recettes techniques."""
from datetime import date
import random

from .calendar import generate_slots
from .domain import Doctor, Record, Rules


def configured_rules(seconds=30):
    rules = Rules(gap_confirmed=True, max_seconds=seconds)
    rules.templates[0].start, rules.templates[0].end = "19:00", "24:00"
    return rules


def demo_doctors():
    return [Doctor(f"FICTIF {n:02}", "Médecin", id=f"DEMO-{n:03}") for n in range(1, 31)]


def demo_records(doctors, rules):
    # Dix années complètes de dates de couverture fictive ; l'absence de preuve
    # administrative de participation complète n'est pas assimilée à une couverture attestée.
    slots = generate_slots(date(2016, 1, 1), date(2025, 12, 31), rules)
    rng = random.Random(42)
    last = {d.id: date(1900, 1, 1) for d in doctors}
    counts = {d.id: 0 for d in doctors}
    records = []
    for s in slots:
        candidates = [d for d in doctors if (s.date - last[d.id]).days >= rules.min_gap]
        rng.shuffle(candidates)
        chosen = min(candidates, key=lambda d: counts[d.id])
        records.append(Record(s, chosen.id, id=f"DEMO-H-{len(records):05}", source="DÉMONSTRATION FICTIVE"))
        counts[chosen.id] += 1
        last[chosen.id] = s.date
    return records


