"""Contrôles métier sans dépendance à OR-Tools."""
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import date
from .calendar import add_months
from .domain import Doctor, Plan, Record, Rules, parse_date


@dataclass
class Report:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    repeats: list[str] = field(default_factory=list)

    @property
    def ok(self):
        return not self.errors


def previous_occurrences(doctor_id, slot, history, years):
    if not slot.holidays or years == 0:
        return []
    lower = add_months(slot.date, -12 * years)
    return [r for r in history if r.doctor_id == doctor_id
            and lower <= r.slot.date < slot.date
            and set(slot.holidays).intersection(r.slot.holidays)]


def validate(plan: Plan, doctors: list[Doctor], rules: Rules, history: list[Record],
             history_complete=False) -> Report:
    report = Report()
    try:
        rules.check()
        for d in doctors:
            d.check()
    except ValueError as exc:
        report.errors.append(str(exc))
    by_id = {d.id: d for d in doctors}
    if not plan.slots:
        report.errors.append("Aucun créneau : un planning vide ne peut pas être validé.")
    if len(by_id) != len(doctors):
        report.errors.append("Identifiants de médecins dupliqués.")
    if len({s.id for s in plan.slots}) != len(plan.slots):
        report.errors.append("Identifiants de créneaux dupliqués.")
    slots = {s.id: s for s in plan.slots}
    extra = set(plan.assignments) - set(slots)
    if extra:
        report.errors.append("Affectations rattachées à des créneaux inconnus.")
    assigned = defaultdict(list)
    totals, months = Counter(), Counter()
    for s in plan.slots:
        roster = plan.assignments.get(s.id, [])
        if not parse_date(plan.start) <= s.date <= parse_date(plan.end):
            report.errors.append(f"Créneau hors période : {s.day}.")
        if len(roster) != s.required:
            report.errors.append(f"{s.day} {s.category} : {s.required} médecin(s) requis, {len(roster)} affecté(s).")
        if len(set(roster)) != len(roster):
            report.errors.append(f"{s.day} : un médecin remplit plusieurs postes du même créneau.")
        if s.interval is None:
            report.errors.append(f"{s.day} : horaires du planning inconnus.")
        for ident in roster:
            d = by_id.get(ident)
            if not d:
                report.errors.append(f"Médecin inconnu : {ident}.")
                continue
            # Évaluation propre au validateur : ne réutilise pas les candidats du modèle.
            participating = any(p.contains(s.date) for p in d.participation)
            suspended = any(p.contains(s.date) for p in d.suspensions)
            if not participating or suspended or (d.deactivated_on and s.day >= d.deactivated_on):
                report.errors.append(f"{d.name}, {s.day} : hors participation / suspension.")
            if any(p.contains(s.date) for p in d.unavailable):
                report.errors.append(f"{d.name}, {s.day} : indisponible.")
            assigned[ident].append(s)
            totals[ident] += 1
            months[ident, s.day[:7]] += 1
            previous = previous_occurrences(ident, s, history, rules.holiday_years)
            if previous:
                text = f"{d.name}, {s.day} : répétition {', '.join(s.holidays)} ; occurrences connues : " + ", ".join(sorted({r.slot.day for r in previous}))
                report.repeats.append(text)
                if rules.holiday_mode == "STRICT":
                    report.errors.append(text)
    for slot_id, ids in plan.locks.items():
        if slot_id not in slots or not set(ids).issubset(plan.assignments.get(slot_id, [])):
            report.errors.append(f"Verrouillage non respecté : {slot_id}.")
    historical = defaultdict(list)
    for r in history:
        historical[r.doctor_id].append(r.slot)
    for d in doctors:
        if d.max_total is not None and totals[d.id] > d.max_total:
            report.errors.append(f"{d.name} : quota total impératif dépassé.")
        for (ident, month), count in months.items():
            if ident == d.id and d.max_month is not None and count > d.max_month:
                report.errors.append(f"{d.name}, {month} : quota mensuel impératif dépassé.")
        current = sorted(assigned[d.id], key=lambda s: (s.day, s.start or ""))
        for i, s in enumerate(current):
            for other in current[:i] + historical[d.id]:
                gap = abs((s.date - other.date).days)
                if gap < rules.min_gap:
                    report.errors.append(f"{d.name} : espacement {gap} j entre {other.day} et {s.day}, minimum {rules.min_gap} j.")
                if s.day == other.day and rules.distinct_day:
                    report.errors.append(f"{d.name}, {s.day} : deux gardes le même jour.")
                if s.interval and other.interval:
                    if max(s.interval[0], other.interval[0]) < min(s.interval[1], other.interval[1]):
                        report.errors.append(f"{d.name} : chevauchement le {s.day}.")
                elif s.day == other.day:
                    report.errors.append(f"{d.name}, {s.day} : horaires historiques inconnus, absence de chevauchement invérifiable.")
    if not history_complete:
        report.warnings.append("Historique incomplet ou couverture non déclarée. Absence d'occurrence connue ne signifie pas absence de garde. Aucune compensation de dette historique.")
    if any(r.slot.interval is None for r in history):
        report.warnings.append("Des horaires historiques sont inconnus : heures et chevauchements historiques partiellement invérifiables ; dates utilisées pour l'espacement.")
    report.warnings.extend(report.repeats)
    report.errors = list(dict.fromkeys(report.errors))
    return report
