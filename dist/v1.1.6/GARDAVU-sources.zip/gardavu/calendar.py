"""Calendrier grégorien métropolitain et génération sans double couverture."""
import calendar as std_calendar
from datetime import date, timedelta
from fractions import Fraction
from .domain import CATEGORIES, Rules, Slot, Template, minute, parse_date

HOLIDAY_NAMES = {
    "JOUR_AN": "Jour de l'an", "LUNDI_PAQUES": "Lundi de Pâques",
    "TRAVAIL": "Fête du travail", "VICTOIRE": "Victoire 1945",
    "ASCENSION": "Ascension", "LUNDI_PENTECOTE": "Lundi de Pentecôte",
    "FETE_NATIONALE": "Fête nationale", "ASSOMPTION": "Assomption",
    "TOUSSAINT": "Toussaint", "ARMISTICE": "Armistice", "NOEL": "Noël",
}


def add_months(day: date, months: int) -> date:
    """Ancrage au jour du mois, ramené au dernier jour si nécessaire."""
    year, month = divmod(day.year * 12 + day.month - 1 + months, 12)
    return date(year, month + 1, min(day.day, std_calendar.monthrange(year, month + 1)[1]))


def period_end(start: date, months: int) -> date:
    if months < 1 or months > 120:
        raise ValueError("Choisissez une durée de 1 à 120 mois.")
    # L'anniversaire décalé est exclu ; la date précédente est la fin incluse.
    return add_months(start, months) - timedelta(days=1)


def calendar_months(start: date, end: date) -> Fraction:
    """Mois calendaires complets + fractions des mois de bord."""
    total = Fraction()
    current = start.replace(day=1)
    while current <= end:
        length = std_calendar.monthrange(current.year, current.month)[1]
        last = current.replace(day=length)
        covered = (min(end, last) - max(start, current)).days + 1
        total += Fraction(covered, length)
        current = add_months(current, 1)
    return total


def days(start: date, end: date):
    for n in range((end - start).days + 1):
        yield start + timedelta(days=n)


def easter(year: int) -> date:
    # Algorithme grégorien Meeus/Jones/Butcher, sans table annuelle.
    a = year % 19
    b, c = divmod(year, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month, rem = divmod(h + l - 7 * m + 114, 31)
    return date(year, month, rem + 1)


def holidays(year: int) -> dict[date, tuple[str, ...]]:
    ep = easter(year)
    pairs = [(date(year, 1, 1), "JOUR_AN"), (ep + timedelta(days=1), "LUNDI_PAQUES"),
             (date(year, 5, 1), "TRAVAIL"), (date(year, 5, 8), "VICTOIRE"),
             (ep + timedelta(days=39), "ASCENSION"),
             (ep + timedelta(days=50), "LUNDI_PENTECOTE"),
             (date(year, 7, 14), "FETE_NATIONALE"), (date(year, 8, 15), "ASSOMPTION"),
             (date(year, 11, 1), "TOUSSAINT"), (date(year, 11, 11), "ARMISTICE"),
             (date(year, 12, 25), "NOEL")]
    result = {}
    for day, ident in pairs:
        result[day] = tuple(sorted((*result.get(day, ()), ident)))
    return result


def holiday_ids(day: date, rules: Rules):
    ids = set(holidays(day.year).get(day, ()))
    exception = rules.holiday_exceptions.get(day.isoformat(), {})
    ids.difference_update(exception.get("remove", []))
    ids.update(exception.get("add", []))
    return tuple(sorted(ids))


def generate_slots(start: date, end: date, rules: Rules) -> list[Slot]:
    rules.check()
    if end < start or (end - start).days > 3660:
        raise ValueError("Période invalide ou supérieure à dix ans.")
    result = []
    for day in days(start, end):
        ids = holiday_ids(day, rules)
        kind = "FERIE" if ids else "DIMANCHE" if day.weekday() == 6 else "SAMEDI" if day.weekday() == 5 else "SEMAINE"
        if day.isoformat() in rules.date_exceptions:
            selected = [Template(**x) for x in rules.date_exceptions[day.isoformat()]]
        else:
            # Version la plus récente de chaque modèle ; une désactivation est une version.
            latest = {}
            for t in rules.templates:
                if parse_date(t.effective) <= day and (not t.until or day <= parse_date(t.until)):
                    if t.id in latest and latest[t.id].effective == t.effective:
                        raise ValueError(f"Deux versions du modèle {t.id} prennent effet le {t.effective}.")
                    if t.id not in latest or t.effective > latest[t.id].effective:
                        latest[t.id] = t
            selected = [t for t in latest.values() if t.kind == kind and t.enabled]
        seen = set()
        for t in selected:
            if not t.enabled:
                continue
            if t.start is None or t.end is None:
                raise ValueError(f"Horaires incomplets : {day:%d/%m/%Y}, modèle {t.id}. Configurez les soirs de semaine.")
            if t.id in seen or t.category not in CATEGORIES or not isinstance(t.required, int) or t.required < 1:
                raise ValueError(f"Modèle invalide ou dupliqué : {t.id}.")
            seen.add(t.id)
            if minute(t.start) >= 1440:
                raise ValueError("Le début doit être antérieur à 24:00.")
            slot = Slot(f"{day.isoformat()}:{t.id}", day.isoformat(), t.category,
                        t.start, t.end, t.required, ids)
            slot.interval
            result.append(slot)
    if not result:
        raise ValueError("Aucun créneau actif dans la période.")
    return sorted(result, key=lambda s: (s.day, s.start, s.id))
