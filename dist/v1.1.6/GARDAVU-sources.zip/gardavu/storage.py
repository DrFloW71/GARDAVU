"""Projets SQLite, sauvegarde cohérente et autorité par affectation effective."""
from contextlib import contextmanager
from dataclasses import asdict
from datetime import date, datetime
import json
import os
from pathlib import Path
import sqlite3

from .domain import Doctor, Plan, Record, Rules, dumps, uid

SCHEMA = 1


class Project:
    def __init__(self, path, create=False):
        self.path = Path(path).resolve()
        self.conn = None
        self._lock = None
        if self.path.suffix.lower() != ".gardavu":
            raise ValueError("Choisissez un fichier projet avec l'extension .gardavu.")
        if create and self.path.exists():
            raise ValueError("Ce projet existe déjà. Ouvrez-le ou choisissez un autre nom.")
        if not create and not self.path.is_file():
            raise ValueError("Projet introuvable.")
        try:
            self._lock = open(str(self.path) + ".lock", "a+b")
            self._lock.seek(0)
            if not self._lock.read(1):
                self._lock.write(b"0")
                self._lock.flush()
            self._lock.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self._lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            if self._lock:
                self._lock.close()
                self._lock = None
            raise ValueError("Projet déjà ouvert en écriture ou dossier non inscriptible. Fermez l'autre instance ou choisissez explicitement un autre dossier.") from exc
        try:
            self.conn = sqlite3.connect(self.path, timeout=3)
            self.conn.execute("PRAGMA foreign_keys=ON")
            version = self.conn.execute("PRAGMA user_version").fetchone()[0]
            if version > SCHEMA:
                raise ValueError("Projet créé par une version plus récente de GARDAVU.")
            if not create and version == 0:
                raise ValueError("Ce fichier n'est pas un projet GARDAVU reconnu.")
            if version < SCHEMA:
                if not create:
                    self.backup(reason="avant-migration")
                self._migrate(version)
            check = self.conn.execute("PRAGMA quick_check").fetchone()[0]
            if check != "ok":
                raise ValueError("Base endommagée : " + check)
        except Exception:
            self.close()
            raise

    def _migrate(self, version):
        if version == 0:
            with self.conn:
                self.conn.executescript("""
                    CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                    CREATE TABLE doctors(id TEXT PRIMARY KEY, payload TEXT NOT NULL);
                    CREATE TABLE plans(id TEXT PRIMARY KEY, state TEXT NOT NULL, payload TEXT NOT NULL,
                                       created TEXT NOT NULL);
                    CREATE TABLE history(id TEXT PRIMARY KEY, doctor_id TEXT NOT NULL REFERENCES doctors(id),
                        day TEXT NOT NULL, slot_id TEXT NOT NULL, payload TEXT NOT NULL,
                        effective INTEGER NOT NULL DEFAULT 1, plan_id TEXT);
                    CREATE INDEX history_date ON history(day, effective);
                    CREATE TABLE imports(fingerprint TEXT PRIMARY KEY, imported TEXT NOT NULL);
                    CREATE TABLE audit(id INTEGER PRIMARY KEY, at TEXT NOT NULL, action TEXT NOT NULL, payload TEXT NOT NULL);
                    PRAGMA user_version=1;
                """)
                self.conn.execute("INSERT INTO meta VALUES('rules', ?)", (dumps(Rules()),))
                self.conn.execute("INSERT INTO meta VALUES('coverage', '[]')")
                self.conn.execute("INSERT INTO meta VALUES('demo', 'false')")
        if self.conn.execute("PRAGMA user_version").fetchone()[0] != SCHEMA:
            raise ValueError("Migration non disponible.")

    @contextmanager
    def transaction(self):
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def audit(self, action, payload):
        self.conn.execute("INSERT INTO audit(at,action,payload) VALUES(?,?,?)",
                          (datetime.now().astimezone().isoformat(), action, dumps(payload)))

    def meta(self, key, default=None):
        row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def set_meta(self, key, value):
        with self.transaction():
            self.conn.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (key, dumps(value)))
            self.audit("parametre", {"key": key, "value": value})

    def rules(self):
        return Rules.from_dict(self.meta("rules"))

    def save_rules(self, rules):
        # Les règles incomplètes peuvent être enregistrées, mais pas générées.
        self.set_meta("rules", asdict(rules))

    def doctors(self):
        return [Doctor.from_dict(json.loads(r[0])) for r in self.conn.execute("SELECT payload FROM doctors ORDER BY id")]

    def save_doctor(self, doctor):
        doctor.check()
        with self.transaction():
            self.conn.execute("INSERT INTO doctors VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload", (doctor.id, dumps(doctor)))
            self.audit("medecin", asdict(doctor))

    def history(self):
        return [Record.from_dict(json.loads(r[0])) for r in self.conn.execute("SELECT payload FROM history WHERE effective=1 ORDER BY day,id")]

    def plans(self):
        return [Plan.from_dict({**json.loads(payload), "state": state})
                for state, payload in self.conn.execute("SELECT state,payload FROM plans ORDER BY created DESC")]

    def save_draft(self, plan, action="brouillon"):
        if plan.state != "BROUILLON":
            raise ValueError("Créez une nouvelle version pour modifier un planning validé.")
        with self.transaction():
            row = self.conn.execute("SELECT state FROM plans WHERE id=?", (plan.id,)).fetchone()
            if row and row[0] != "BROUILLON":
                raise ValueError("Version validée immuable.")
            self.conn.execute("INSERT OR REPLACE INTO plans VALUES(?,?,?,?)",
                              (plan.id, plan.state, dumps(plan), datetime.now().astimezone().isoformat()))
            self.audit(action, {"plan": plan.id, "metadata": plan.metadata})

    def validate_plan(self, plan, confirm_repeats=False, replace=False):
        from .validation import validate
        if plan.state != "BROUILLON":
            raise ValueError("Seul un brouillon peut être validé.")
        historical = self.history()
        inside = [r for r in historical if plan.start <= r.slot.day <= plan.end]
        outside = [r for r in historical if r not in inside]
        if inside and not replace:
            raise ValueError("Cette période contient déjà des gardes effectives. Confirmez explicitement leur remplacement.")
        # Les gardes passées effectives ne sont jamais réécrites par une nouvelle génération.
        today = date.today().isoformat()
        def signatures(records):
            return {(r.slot.day, r.slot.category, r.slot.start, r.slot.end, r.doctor_id) for r in records}
        old_past = signatures([r for r in inside if r.slot.day < today])
        new_past = {(s.day, s.category, s.start, s.end, d) for s in plan.slots if s.day < today
                    for d in plan.assignments.get(s.id, [])}
        if inside and old_past != new_past:
            raise ValueError("Le remplacement modifierait des gardes passées. Créez une période future ou corrigez l'historique explicitement.")
        rules = self.rules()
        report = validate(plan, self.doctors(), rules, outside, self.coverage_complete(plan.start, rules.recent_months))
        if report.errors:
            raise ValueError("Planning non conforme :\n" + "\n".join(report.errors[:30]))
        if report.repeats and not confirm_repeats:
            raise ValueError("Confirmation explicite requise pour les répétitions de fêtes.\n" + "\n".join(report.repeats))
        snapshot = Plan.from_dict(json.loads(dumps(plan)))
        snapshot.state = "VALIDE"
        snapshot.metadata.update(validated_rules=json.loads(dumps(rules)), validation_warnings=report.warnings,
                                 validated_at=datetime.now().astimezone().isoformat(),
                                 doctors_snapshot=[asdict(d) for d in self.doctors()],
                                 history_coverage=self.meta("coverage", []))
        self.backup(reason="avant-validation")
        with self.transaction():
            previous = {r[0] for r in self.conn.execute("SELECT DISTINCT plan_id FROM history WHERE effective=1 AND day BETWEEN ? AND ?", (plan.start, plan.end)) if r[0]}
            self.conn.execute("UPDATE history SET effective=0 WHERE day BETWEEN ? AND ?", (plan.start, plan.end))
            for ident in previous:
                self.conn.execute("UPDATE plans SET state='REMPLACE' WHERE id=?", (ident,))
            for s in plan.slots:
                for ident in plan.assignments[s.id]:
                    r = Record(s, ident, source="GARDAVU")
                    self.conn.execute("INSERT INTO history VALUES(?,?,?,?,?,1,?)",
                                      (r.id, ident, s.day, s.id, dumps(r), plan.id))
            self.conn.execute("INSERT OR REPLACE INTO plans VALUES(?,?,?,?)",
                              (snapshot.id, snapshot.state, dumps(snapshot), datetime.now().astimezone().isoformat()))
            self.audit("validation_remplacement" if inside else "validation", {"plan": snapshot.id, "repeats_confirmed": confirm_repeats, "replaced": sorted(previous)})
        return snapshot

    def archive(self, plan):
        if plan.state != "VALIDE":
            raise ValueError("Seul un planning validé peut être archivé.")
        with self.transaction():
            self.conn.execute("UPDATE plans SET state='ARCHIVE' WHERE id=?", (plan.id,))
            self.audit("archivage", {"plan": plan.id})
        plan.state = "ARCHIVE"

    def coverage_complete(self, start, months):
        from .calendar import add_months
        from .domain import parse_date
        lower, upper = add_months(parse_date(start), -months), parse_date(start)
        for entry in sorted(self.meta("coverage", []), key=lambda v: v["start"]):
            a, b = parse_date(entry["start"]), parse_date(entry["end"])
            if a <= lower <= b:
                from datetime import timedelta
                lower = b + timedelta(days=1)
        return lower >= upper

    def backup(self, destination=None, reason="sauvegarde"):
        if destination is None:
            folder = self.path.parent / (self.path.stem + "_sauvegardes")
            folder.mkdir(exist_ok=True)
            destination = folder / f"{self.path.stem}_{datetime.now():%Y%m%d_%H%M%S_%f}_{reason}.gardavu"
        destination = Path(destination).resolve()
        if destination == self.path or destination.exists():
            raise ValueError("La sauvegarde doit être un nouveau fichier, distinct du projet ouvert.")
        target = sqlite3.connect(destination)
        try:
            self.conn.backup(target)
            if target.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("La sauvegarde n'a pas passé le contrôle d'intégrité.")
        finally:
            target.close()
        return destination

    @staticmethod
    def restore(source, destination):
        # Restaurer vers un nouveau fichier permet de garder le projet précédent.
        with Project(source) as project:
            return project.backup(destination)

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None
        if self._lock:
            self._lock.close()
            self._lock = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
