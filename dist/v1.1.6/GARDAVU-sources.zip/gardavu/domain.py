from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta
from functools import cached_property
import json
from uuid import uuid4

CATEGORIES = {
    "SEMAINE": "Soir de semaine", "SAMEDI": "Samedi",
    "DIMANCHE_JOUR": "Dimanche jour", "DIMANCHE_NUIT": "Dimanche nuit",
    "FERIE_JOUR": "Férié jour", "FERIE_NUIT": "Férié nuit",
}


def uid() -> str:
    return str(uuid4())


def parse_date(value) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str) and len(value.strip()) == 10 and value.strip()[4] == "-":
        try:
            return date.fromisoformat(value.strip())
        except ValueError:
            pass
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(str(value).strip(), fmt).date()
        except ValueError:
            pass
    raise ValueError(f"Date invalide : {value!r}. Utilisez JJ/MM/AAAA.")


def minute(value: str) -> int:
    if value == "24:00":
        return 1440
    try:
        h, m = map(int, value.split(":"))
        if 0 <= h <= 23 and 0 <= m <= 59:
            return 60 * h + m
    except (ValueError, AttributeError):
        pass
    raise ValueError(f"Horaire invalide : {value!r} (HH:MM attendu).")


@dataclass
class Span:
    start: str
    end: str | None = None

    def __post_init__(self):
        parse_date(self.start)
        if self.end and parse_date(self.end) < parse_date(self.start):
            raise ValueError("La fin d'une période précède son début.")

    def contains(self, day: date) -> bool:
        return parse_date(self.start) <= day and (not self.end or day <= parse_date(self.end))


@dataclass
class Doctor:
    last: str
    first: str = ""
    id: str = field(default_factory=uid)
    display: str = ""
    coefficient: float = 1.0
    participation: list[Span] = field(default_factory=lambda: [Span("1900-01-01")])
    suspensions: list[Span] = field(default_factory=list)
    unavailable: list[Span] = field(default_factory=list)
    aliases: list[str] = field(default_factory=list)
    max_total: int | None = None
    max_month: int | None = None
    deactivated_on: str | None = None

    @property
    def name(self):
        return self.display or f"{self.last} {self.first}".strip()

    def participates(self, day: date) -> bool:
        return (self.coefficient > 0
                and (not self.deactivated_on or day < parse_date(self.deactivated_on))
                and any(p.contains(day) for p in self.participation)
                and not any(p.contains(day) for p in self.suspensions))

    def available(self, day: date) -> bool:
        return self.participates(day) and not any(p.contains(day) for p in self.unavailable)

    @classmethod
    def from_dict(cls, obj):
        obj = dict(obj)
        for k in ("participation", "suspensions", "unavailable"):
            if k in obj:
                obj[k] = [Span(**x) for x in obj[k]]
        return cls(**obj)

    def check(self):
        import math
        if not self.last.strip() or not math.isfinite(self.coefficient) or self.coefficient <= 0:
            raise ValueError("Nom et coefficient strictement positif requis.")
        if any(v is not None and (not isinstance(v, int) or v < 0)
               for v in (self.max_total, self.max_month)):
            raise ValueError("Les limites impératives doivent être des entiers positifs ou nuls.")


@dataclass
class Template:
    id: str
    kind: str
    category: str
    start: str | None
    end: str | None
    required: int = 1
    effective: str = "1900-01-01"
    until: str | None = None
    enabled: bool = True


def default_templates():
    return [Template("soir", "SEMAINE", "SEMAINE", None, None),
            Template("samedi", "SAMEDI", "SAMEDI", "14:00", "24:00"),
            Template("dimanche-jour", "DIMANCHE", "DIMANCHE_JOUR", "08:00", "19:00"),
            Template("dimanche-nuit", "DIMANCHE", "DIMANCHE_NUIT", "19:00", "24:00"),
            Template("ferie-jour", "FERIE", "FERIE_JOUR", "08:00", "19:00"),
            Template("ferie-nuit", "FERIE", "FERIE_NUIT", "19:00", "24:00")]


@dataclass
class Rules:
    templates: list[Template] = field(default_factory=default_templates)
    min_gap: int = 7
    gap_confirmed: bool = False
    distinct_day: bool = True
    holiday_mode: str = "PRIORITAIRE"
    holiday_years: int = 10
    recent_months: int = 12
    weekday_threshold: int | None = None
    max_seconds: float = 30
    seed: int = 42
    workers: int = 1
    # Une exception remplace intégralement le modèle de la date.
    date_exceptions: dict[str, list[dict]] = field(default_factory=dict)
    # Pour une date : identifiants à ajouter et/ou retirer.
    holiday_exceptions: dict[str, dict] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, obj):
        obj = dict(obj)
        if "templates" in obj:
            obj["templates"] = [Template(**x) for x in obj["templates"]]
        return cls(**obj)

    def check(self):
        if not self.gap_confirmed:
            raise ValueError("Confirmez l'espacement minimal proposé de 7 jours dans les paramètres.")
        if self.min_gap < 0 or self.holiday_years < 0 or self.recent_months < 0:
            raise ValueError("Les horizons et l'espacement doivent être positifs ou nuls.")
        if self.holiday_mode not in ("STRICT", "PRIORITAIRE"):
            raise ValueError("Mode des fêtes : STRICT ou PRIORITAIRE.")
        if not 0.01 <= self.max_seconds <= 3600 or not 1 <= self.workers <= 32:
            raise ValueError("Durée : 0,01 à 3600 secondes ; travailleurs : 1 à 32.")
        if self.weekday_threshold is not None and self.weekday_threshold < 1:
            raise ValueError("Seuil de répétition hebdomadaire : au moins 1.")


@dataclass(frozen=True)
class Slot:
    id: str
    day: str
    category: str
    start: str | None
    end: str | None
    required: int = 1
    holidays: tuple[str, ...] = ()

    @cached_property
    def date(self):
        return parse_date(self.day)

    @cached_property
    def interval(self):
        if self.start is None or self.end is None:
            return None
        a, b = minute(self.start), minute(self.end)
        if b == 0:
            b = 1440
        if b <= a:
            raise ValueError("Fin de garde antérieure au début (seule la fin à minuit est acceptée).")
        base = datetime.combine(self.date, datetime.min.time())
        return base + timedelta(minutes=a), base + timedelta(minutes=b)

    @cached_property
    def hours(self):
        itv = self.interval
        return (itv[1] - itv[0]).total_seconds() / 3600 if itv else None

    @classmethod
    def from_dict(cls, obj):
        return cls(**{**obj, "holidays": tuple(obj.get("holidays", ()))})


@dataclass
class Record:
    slot: Slot
    doctor_id: str
    id: str = field(default_factory=uid)
    source: str = ""

    @classmethod
    def from_dict(cls, obj):
        return cls(**{**obj, "slot": Slot.from_dict(obj["slot"])})


@dataclass
class Plan:
    start: str
    end: str
    slots: list[Slot]
    assignments: dict[str, list[str]] = field(default_factory=dict)
    locks: dict[str, list[str]] = field(default_factory=dict)
    id: str = field(default_factory=uid)
    state: str = "BROUILLON"
    solver_status: str = "UNKNOWN"
    metadata: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, obj):
        return cls(**{**obj, "slots": [Slot.from_dict(x) for x in obj["slots"]]})


def dumps(obj):
    return json.dumps(asdict(obj) if hasattr(obj, "__dataclass_fields__") else obj,
                      ensure_ascii=False, sort_keys=True, allow_nan=False)
