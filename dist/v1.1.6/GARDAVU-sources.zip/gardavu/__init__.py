"""GARDAVU : planification locale des gardes."""

__version__ = "1.1.6"
__author__ = "Dr Florian Ronez"
