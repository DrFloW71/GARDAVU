"""Composants de présentation : barres adaptatives et tableaux lisibles."""
import tkinter as tk
from tkinter import ttk
from .ui_theme import theme_for


class FlowToolbar(ttk.Frame):
    """Conserve toutes les actions visibles en passant à la ligne si nécessaire."""
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self._pending = None
        self.bind("<Configure>", self._schedule)

    def _schedule(self, event=None):
        if self._pending is None:
            self._pending = self.after_idle(self.reflow)

    def reflow(self):
        self._pending = None
        if not self.winfo_exists():
            return
        available = max(1, self.winfo_width())
        x, y, row_height = 0, 0, 0
        for widget in self.winfo_children():
            width = min(widget.winfo_reqwidth(), available)
            height = widget.winfo_reqheight()
            if x and x + width > available:
                x, y, row_height = 0, y + row_height + 6, 0
            widget.pack_forget()
            widget.place(x=x, y=y, width=width, height=height)
            x += width + 6
            row_height = max(row_height, height)
        requested = max(1, y + row_height)
        if int(self.cget("height")) != requested:
            self.configure(height=requested)


class DataTreeview(ttk.Treeview):
    def __init__(self, master, *, empty_text="Aucune donnée à afficher.", **kwargs):
        super().__init__(master, **kwargs)
        self._row_counter = 0
        self._headings = {}
        self._descending = {}
        self.empty_label = ttk.Label(self, text=empty_text, style="Empty.TLabel", anchor="center", justify="center", wraplength=480)
        self.empty_label.place(relx=.5, rely=.55, anchor="center")
        self.bind("<Configure>", lambda event: self.empty_label.configure(wraplength=max(160, event.width - 60)))
        theme = theme_for(self)
        if theme:
            theme.apply_widgets(self)

    def insert(self, parent, index, iid=None, **kwargs):
        tags = tuple(kwargs.pop("tags", ()))
        kwargs["tags"] = tags if "attention" in tags else tags + ("row_odd" if self._row_counter % 2 else "row_even",)
        result = super().insert(parent, index, iid=iid, **kwargs)
        self._row_counter += 1
        self.empty_label.place_forget()
        return result

    def delete(self, *items):
        super().delete(*items)
        if not self.get_children():
            self._row_counter = 0
            self.empty_label.place(relx=.5, rely=.55, anchor="center")

    def sortable_heading(self, column, text):
        self._headings[column] = text
        self.heading(column, text=text, command=lambda: self.sort_column(column))

    def sort_column(self, column):
        reverse = self._descending.get(column, False)
        def key(item):
            value = self.set(item, column).strip()
            try:
                return (0, float(value.lstrip("×").replace(",", ".")))
            except ValueError:
                return (1, value.casefold())
        items = sorted(self.get_children(), key=key, reverse=reverse)
        for index, item in enumerate(items):
            self.move(item, "", index)
            tags = tuple(t for t in self.item(item, "tags") if t not in ("row_even", "row_odd"))
            self.item(item, tags=tags if "attention" in tags else tags + ("row_odd" if index % 2 else "row_even",))
        for name, label in self._headings.items():
            self.heading(name, text=label + (" ↓" if reverse else " ↑") if name == column else label)
        self._descending[column] = not reverse
