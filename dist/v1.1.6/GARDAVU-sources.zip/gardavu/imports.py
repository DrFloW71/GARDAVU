"""Lecture sans exécution de formules ; préparation séparée de l'écriture."""
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, time
import csv
import hashlib
import json
from pathlib import Path
import unicodedata

from openpyxl import load_workbook
from openpyxl.utils.datetime import from_excel

from .calendar import HOLIDAY_NAMES, holiday_ids
from .domain import CATEGORIES, Doctor, Record, Slot, Span, dumps, minute, parse_date, uid


def normalize(value):
    return " ".join("".join(c for c in unicodedata.normalize("NFKD", str(value or ""))
                             if not unicodedata.combining(c)).casefold().replace("-", " ").split())


def category(value):
    names = {normalize(k): k for k in CATEGORIES}
    names.update({normalize(v): k for k, v in CATEGORIES.items()})
    if normalize(value) not in names:
        raise ValueError(f"Catégorie inconnue : {value}. Valeurs : {', '.join(CATEGORIES)}")
    return names[normalize(value)]


def holiday_identifier(value):
    names = {normalize(k): k for k in HOLIDAY_NAMES}
    names.update({normalize(v): k for k, v in HOLIDAY_NAMES.items()})
    return names.get(normalize(value), normalize(value).upper().replace(" ", "_"))


def read_sheets(path):
    path = Path(path)
    if path.suffix.lower() == ".csv":
        with path.open(encoding="utf-8-sig", newline="") as stream:
            sample = stream.read(8192)
            stream.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=";,\t")
            except csv.Error:
                dialect = csv.excel
            return {"CSV": list(csv.reader(stream, dialect))}
    if path.suffix.lower() != ".xlsx":
        raise ValueError("Formats pris en charge : .xlsx et .csv. Convertissez les .xls avec votre tableur.")
    workbook = load_workbook(path, read_only=True, data_only=False, keep_links=False)
    result = {}
    try:
        for sheet in workbook:
            rows = []
            for row in sheet.iter_rows():
                values = []
                for c in row:
                    if c.data_type == "f":
                        raise ValueError(f"Formule refusée : feuille {sheet.title}, cellule {c.coordinate}. Collez les valeurs avant import.")
                    value = c.value
                    if isinstance(value, (int, float)) and c.is_date:
                        value = from_excel(value, workbook.epoch)
                    values.append(value)
                rows.append(values)
            result[sheet.title] = rows
    finally:
        workbook.close()
    return result


def data_rows(rows, header_row=0):
    if not rows or header_row >= len(rows):
        raise ValueError("Feuille vide ou ligne d'en-têtes absente.")
    headers = [str(v or "").strip() for v in rows[header_row]]
    if len([v for v in headers if v]) != len(set(v for v in headers if v)):
        raise ValueError("En-têtes dupliqués. Renommez les colonnes avant import.")
    return headers, [(n + header_row + 2, dict(zip(headers, row)))
                     for n, row in enumerate(rows[header_row + 1:]) if any(v not in (None, "") for v in row)]


def cell(row, mapping, key, default=None):
    value = row.get(mapping.get(key, ""))
    return default if value in (None, "") else value


def excel_date(value):
    if isinstance(value, (int, float)):
        return from_excel(value).date()
    return parse_date(value)


def hour(value):
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        value = value.time()
    if isinstance(value, time):
        return value.strftime("%H:%M")
    if isinstance(value, (int, float)) and 0 <= value <= 1:
        total = round(value * 1440)
        return f"{total // 60:02}:{total % 60:02}"
    text = str(value).strip()
    minute(text)
    return text


@dataclass
class Preview:
    doctors: list[Doctor] = field(default_factory=list)
    records: list[Record] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    unresolved: dict[str, list[str]] = field(default_factory=dict)
    fingerprint: str = ""


def file_fingerprint(path, mode, sheet, mapping):
    digest = hashlib.sha256(Path(path).read_bytes())
    digest.update(json.dumps([mode, sheet, mapping], sort_keys=True).encode())
    return digest.hexdigest()


def prepare_doctors(rows, mapping, existing, header_row=0):
    preview = Preview()
    headers, data = data_rows(rows, header_row)
    known = {d.id: d for d in existing}
    seen = set()
    for n, row in data:
        try:
            last = str(cell(row, mapping, "nom", "")).strip()
            first = str(cell(row, mapping, "prenom", "")).strip()
            ident = str(cell(row, mapping, "id", "")).strip()
            if not last:
                raise ValueError("Nom manquant.")
            same_name = [d for d in existing if normalize(d.last) == normalize(last) and normalize(d.first) == normalize(first)]
            if not ident and same_name:
                raise ValueError("Nom déjà connu : renseignez explicitement son identifiant pour une mise à jour, ou un identifiant distinct pour un homonyme.")
            ident = ident or uid()
            if ident in seen:
                raise ValueError("Identifiant présent plusieurs fois dans l'import.")
            seen.add(ident)
            # Mise à jour de champs fournis uniquement, préserver absences, alias et limites.
            doctor = Doctor.from_dict(json.loads(dumps(known[ident]))) if ident in known else Doctor(last, first, id=ident)
            doctor.last, doctor.first = last, first
            coefficient = cell(row, mapping, "coefficient")
            if coefficient is not None:
                doctor.coefficient = float(str(coefficient).replace(",", "."))
            start, end = cell(row, mapping, "debut"), cell(row, mapping, "fin")
            if start is not None or end is not None:
                doctor.participation = [Span(excel_date(start).isoformat() if start else "1900-01-01",
                                             excel_date(end).isoformat() if end else None)]
            doctor.check()
            preview.doctors.append(doctor)
            if ident in known:
                preview.warnings.append(f"Ligne {n} : mise à jour explicite de {doctor.name} ({ident}).")
        except (ValueError, TypeError) as exc:
            preview.errors.append(f"Ligne {n} : {exc}")
    return preview


def doctor_matches(value, doctors):
    exact = [d.id for d in doctors if d.id == str(value).strip()]
    if exact:
        return exact
    key = normalize(value)
    return [d.id for d in doctors if key in {normalize(d.name), normalize(f"{d.first} {d.last}"),
                                            normalize(d.last), *[normalize(a) for a in d.aliases]}]


def prepare_history(rows, mapping, doctors, rules, resolutions=None, matrix=None, header_row=0):
    """matrix : dictionnaire colonne médecin -> catégorie ; dates dans mapping['date']."""
    preview = Preview()
    resolutions = resolutions or {}
    headers, data = data_rows(rows, header_row)
    expanded = []
    for n, row in data:
        if matrix:
            for column, cat in matrix.items():
                if row.get(column) not in (None, ""):
                    expanded.append((n, {"date": cell(row, mapping, "date"), "medecin": row[column], "categorie": cat},
                                     {k: k for k in ("date", "medecin", "categorie")}))
        else:
            expanded.append((n, row, mapping))
    seen = set()
    for n, row, cols in expanded:
        try:
            day = excel_date(cell(row, cols, "date"))
            ident_value = cell(row, cols, "id_medecin") or cell(row, cols, "medecin", "")
            key = str(ident_value).strip()
            matches = doctor_matches(key, doctors)
            ident = resolutions.get(key)
            if ident and ident not in {d.id for d in doctors}:
                raise ValueError("Rapprochement vers un médecin inconnu.")
            if not ident:
                if len(matches) != 1:
                    preview.unresolved[key] = matches
                    continue
                ident = matches[0]
            cat = category(cell(row, cols, "categorie"))
            status = normalize(cell(row, cols, "statut", "VALIDE"))
            if status not in ("valide", "validated", "archive", "effectif"):
                preview.warnings.append(f"Ligne {n} ignorée : statut {status!r} non effectif.")
                continue
            a, b = hour(cell(row, cols, "debut")), hour(cell(row, cols, "fin"))
            if a is None or b is None:
                a = b = None
                preview.warnings.append(f"Ligne {n} : horaires inconnus, aucune heure inventée.")
            raw_holidays = cell(row, cols, "fete")
            ids = tuple(sorted({holiday_identifier(v) for v in str(raw_holidays).replace(";", ",").split(",") if v.strip()})) if raw_holidays else holiday_ids(day, rules)
            slot_id = str(cell(row, cols, "id_creneau") or f"{day}:{cat}:{a or '?'}:{b or '?'}")
            required = int(cell(row, cols, "effectif", 1))
            if required < 1:
                raise ValueError("Effectif inférieur à un.")
            slot = Slot(slot_id, day.isoformat(), cat, a, b, required, ids)
            slot.interval
            signature = (day.isoformat(), cat, a, b, ident)
            if signature in seen:
                preview.warnings.append(f"Ligne {n} : doublon interne ignoré.")
                continue
            seen.add(signature)
            preview.records.append(Record(slot, ident, source="Excel/CSV"))
        except (ValueError, TypeError, AttributeError) as exc:
            preview.errors.append(f"Ligne {n} : {exc}")
    return preview


def conflicts(project, preview):
    current = project.history()
    result = []
    wanted = {(r.slot.day, r.slot.category, r.slot.start, r.slot.end, r.doctor_id, r.slot.holidays)
              for r in preview.records}
    for record in preview.records:
        for old in current:
            if (old.slot.day, old.slot.category, old.slot.start, old.slot.end,
                    old.doctor_id, old.slot.holidays) in wanted:
                continue
            same = old.slot.day == record.slot.day and old.slot.category == record.slot.category
            same_hours = old.slot.start == record.slot.start and old.slot.end == record.slot.end
            if same and (old.slot.id == record.slot.id or old.doctor_id == record.doctor_id or same_hours):
                exact = (old.doctor_id == record.doctor_id and old.slot.start == record.slot.start
                         and old.slot.end == record.slot.end and old.slot.holidays == record.slot.holidays)
                if not exact:
                    result.append((record, old))
    return result


def commit_import(project, preview, conflict_policy="error"):
    if preview.fingerprint and project.conn.execute("SELECT 1 FROM imports WHERE fingerprint=?", (preview.fingerprint,)).fetchone():
        return {"imported": 0, "ignored": len(preview.records) + len(preview.doctors), "already_imported": True}
    if preview.errors or preview.unresolved:
        raise ValueError("Corrigez les erreurs et les rapprochements avant confirmation.")
    pairs = conflicts(project, preview)
    if pairs and conflict_policy not in ("ignore", "replace"):
        raise ValueError(f"{len(pairs)} conflit(s) : choisir explicitement ignorer ou remplacer/corriger.")
    project.backup(reason="avant-import")
    imported, ignored = 0, 0
    old = project.history()
    exact = {(r.slot.day, r.slot.category, r.slot.start, r.slot.end, r.doctor_id, r.slot.holidays) for r in old}
    with project.transaction():
        for d in preview.doctors:
            project.conn.execute("INSERT OR REPLACE INTO doctors VALUES(?,?)", (d.id, dumps(d)))
            imported += 1
        for r in preview.records:
            signature = (r.slot.day, r.slot.category, r.slot.start, r.slot.end, r.doctor_id, r.slot.holidays)
            related = [previous for new, previous in pairs if new.id == r.id]
            if signature in exact or (related and conflict_policy == "ignore"):
                ignored += 1
                continue
            for previous in related:
                project.conn.execute("UPDATE history SET effective=0 WHERE id=?", (previous.id,))
                project.conn.execute("UPDATE plans SET state='REMPLACE' WHERE id IN (SELECT plan_id FROM history WHERE id=?)", (previous.id,))
            project.conn.execute("INSERT INTO history VALUES(?,?,?,?,?,1,NULL)",
                                 (r.id, r.doctor_id, r.slot.day, r.slot.id, dumps(r)))
            imported += 1
            exact.add(signature)
        if preview.fingerprint:
            project.conn.execute("INSERT INTO imports VALUES(?,?)", (preview.fingerprint, datetime.now().astimezone().isoformat()))
        project.audit("import", {"fingerprint": preview.fingerprint, "imported": imported,
                                 "ignored": ignored, "conflict_policy": conflict_policy, "warnings": preview.warnings})
    return {"imported": imported, "ignored": ignored, "already_imported": False}
