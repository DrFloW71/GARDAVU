# Projet de licence — à valider

Le texte proposé est dans `gardavu/assets/licence-proposee.txt` et s'affiche
dans la fenêtre Informations et licences. Il n'est pas encore applicable.
Le fichier `LICENSE` contient toujours la licence MIT actuellement fournie.

Auteur confirmé par le créateur : **Dr Florian Ronez**.

> **GARDAVU — Licence d'utilisation non commerciale**
>
> © 2026 Dr Florian Ronez. Tous droits réservés pour les éléments originaux de GARDAVU.
>
> GARDAVU est un logiciel créé par le Dr Florian Ronez.
>
> Toute utilisation de GARDAVU, même à titre gratuit, est soumise à l'autorisation préalable, expresse et écrite de son créateur.
>
> L'utilisation est strictement limitée à des fins non commerciales. La vente, la location du logiciel et la facturation de son accès ou de ses fonctionnalités sont interdites.
>
> Toute redistribution du logiciel à des tiers nécessite également l'accord préalable et écrit de son créateur.
>
> Les composants tiers restent soumis à leurs licences respectives. Les droits impérativement prévus par la loi demeurent applicables.

Point encore à confirmer : la notion d'usage non commercial doit-elle autoriser
l'usage interne par des médecins ou cabinets rémunérés, lorsque le logiciel
lui-même n'est ni vendu, ni loué, ni proposé comme service payant ?

Après validation du texte, il faudra harmoniser le fichier LICENSE, les mentions
de l'interface et la synthèse des dépendances. Les licences des composants tiers
restent distinctes.

Références consultées :
- [Licence MIT](https://opensource.org/license/mit).
- [Article L122-6 du Code de la propriété intellectuelle](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006278919).
- [Article L122-6-1, droits de l'utilisateur autorisé](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006278920).
